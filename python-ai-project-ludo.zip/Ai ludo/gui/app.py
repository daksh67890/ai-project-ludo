import math
import random
import sys
import threading
import tkinter as tk
from tkinter import messagebox, ttk
from typing import List, Optional

try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False

from agents.factory import create_agent
from board import (
    HOME,
    HOME_COLUMN_COORDS,
    HOME_COLUMN_START,
    PLAYER_NAMES,
    SAFE_SQUARES,
    START_SQUARE,
    TRACK_COORDS,
    TRACK_LEN,
    YARD,
    YARD_COORDS,
    abs_square,
    on_track,
    seats_for,
)
from rules import apply_move, get_legal_moves, pass_turn, roll_dice
from state import Rules, new_game


class LudoApp:
    # Colors precisely sampled from reference artwork
    BACKGROUND = '#2c2b67'          # Deep indigo background
    FRAME_COLOR = '#ff9d5b'         # Warm rounded peach-caramel outer frame
    FRAME_BORDER = '#e28250'        # Outer border accent
    BOARD_WHITE = '#ffffff'         # Track cell white
    GRID_LINE = '#d8dce6'           # Thin track grid separator

    # Player 0: Red, Player 1: Green, Player 2: Yellow, Player 3: Blue
    COLORS = ('#e52521', '#00a843', '#fca311', '#1d9bf0')
    YARD_INNER_COLORS = ('#ff5252', '#28c758', '#ffb74d', '#42a5f5')
    YARD_POCKET_COLORS = ('#b71c1c', '#00701a', '#e65100', '#0d47a1')
    STAR_CELL_COLORS = ('#ffcdd2', '#c8e6c9', '#fff9c4', '#bbdefb')
    GOLD_RIM = '#f5c32d'
    GOLD_RIM_DARK = '#b47b10'

    BASE_ORIGINS = ((0, 0), (0, 9), (9, 9), (9, 0))

    # Directional entry arrows right outside home column lanes
    ENTRY_ARROWS = (
        (7, 0, 'right', '#e52521'),    # Red ▶
        (0, 7, 'down', '#00a843'),     # Green ▼
        (7, 14, 'left', '#fca311'),    # Yellow ◀
        (14, 7, 'up', '#1d9bf0'),      # Blue ▲
    )

    SPEEDS = {
        'Slow (800ms)': 800,
        'Normal (350ms)': 350,
        'Fast (120ms)': 120,
        'Turbo (15ms)': 15,
    }

    AGENT_OPTIONS = ('random', 'greedy', 'expectiminimax', 'tuned')

    def __init__(self, root):
        self.root = root
        self.root.title('AI Ludo - Authentic Edition')
        self.root.geometry('1200x780')
        self.root.minsize(1020, 700)
        self.root.state('zoomed')
        self.root.configure(bg=self.BACKGROUND)

        # Options
        self.num_players = tk.IntVar(value=2)
        self.agent_name = tk.StringVar(value='expectiminimax')
        self.depth = tk.IntVar(value=2)
        self.speed_var = tk.StringVar(value='Normal (350ms)')
        self.sound_enabled = tk.BooleanVar(value=True)

        # Rule variants
        self.rule_extra_six = tk.BooleanVar(value=True)
        self.rule_extra_capture = tk.BooleanVar(value=True)
        self.rule_extra_home = tk.BooleanVar(value=True)
        self.rule_three_sixes = tk.BooleanVar(value=True)
        self.rule_exact_finish = tk.BooleanVar(value=True)
        self.rule_blocks = tk.BooleanVar(value=False)

        self.seat_modes = {
            player: tk.StringVar(value='human' if player == 0 else 'greedy')
            for player in range(4)
        }

        # Game engine state
        self.state = None
        self.dice = None
        self.moves = []
        self.selected_token = None
        self.token_hitboxes = []
        self.is_rolling = False
        self.dice_animation_id = None
        self.auto = False
        self.paused = False
        self.ai_turn_id = None
        self.player_rows = {}
        self.history = []

        self._configure_styles()
        self._build()
        self._bind_shortcuts()

    def _bind_shortcuts(self):
        self.root.bind('<space>', self._on_space_key)
        self.root.bind('<Return>', self._on_space_key)
        self.root.bind('<u>', lambda _e: self.undo_move())
        self.root.bind('<U>', lambda _e: self.undo_move())
        self.root.bind('<Control-z>', lambda _e: self.undo_move())
        for num in ('1', '2', '3', '4'):
            self.root.bind(num, lambda _e, n=int(num)-1: self._select_token_by_number(n))

    def _on_space_key(self, event=None):
        if self.is_rolling or self.state is None:
            return
        if self.state.is_terminal():
            self.new_game()
            return
        if self.moves and self.current_is_human() and not self.auto:
            self.move_selected()
        elif self.dice is None and self.current_is_human() and not self.auto:
            self.roll()

    def _select_token_by_number(self, token_idx: int):
        if not self.moves or not self.current_is_human() or self.auto:
            return
        match_move_idx = next((i for i, m in enumerate(self.moves) if m.token == token_idx), None)
        if match_move_idx is not None:
            self.choice.current(match_move_idx)
            self.selected_token = token_idx
            self.move_button.configure(text=f'Move Token {token_idx + 1}')
            self.status.configure(text=f'Token {token_idx + 1} selected! Press Space to confirm.')
            self.draw()


    def _play_sound(self, sound_type: str):
        if not self.sound_enabled.get() or not HAS_WINSOUND:
            return

        def _sound_worker():
            try:
                if sound_type == 'roll':
                    winsound.Beep(700, 35)
                elif sound_type == 'move':
                    winsound.Beep(520, 45)
                elif sound_type == 'capture':
                    winsound.Beep(1100, 70)
                    winsound.Beep(850, 90)
                elif sound_type == 'home':
                    winsound.Beep(950, 60)
                    winsound.Beep(1400, 100)
                elif sound_type == 'win':
                    winsound.Beep(659, 100)
                    winsound.Beep(830, 100)
                    winsound.Beep(987, 120)
                    winsound.Beep(1318, 240)
            except Exception:
                pass

        threading.Thread(target=_sound_worker, daemon=True).start()

    def _configure_styles(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10), foreground='#ffffff')
        style.configure('App.TFrame', background=self.BACKGROUND)
        style.configure('Header.TFrame', background='#1f1e4b')
        style.configure('HeaderTitle.TLabel', background='#1f1e4b', foreground='#ffffff', font=('Segoe UI', 18, 'bold'))
        style.configure('HeaderSubtitle.TLabel', background='#1f1e4b', foreground='#a5b4fc', font=('Segoe UI', 9))
        style.configure('HeaderMeta.TLabel', background='#1f1e4b', foreground='#fbbf24', font=('Segoe UI', 10, 'bold'))
        style.configure('Panel.TFrame', background='#1f1e4b')
        style.configure('Panel.TLabel', background='#1f1e4b', foreground='#ffffff')
        style.configure('Muted.TLabel', background='#1f1e4b', foreground='#94a3b8', font=('Segoe UI', 9))
        style.configure('Hint.TLabel', background='#1f1e4b', foreground='#cbd5e1', font=('Segoe UI', 8))
        style.configure('Section.TLabel', background='#1f1e4b', foreground='#38bdf8', font=('Segoe UI', 9, 'bold'))
        style.configure('Turn.TLabel', background='#1f1e4b', foreground='#ffffff', font=('Segoe UI', 14, 'bold'))
        style.configure('Primary.TButton', background='#0284c7', foreground='white', padding=(10, 7), font=('Segoe UI', 10, 'bold'))
        style.map('Primary.TButton', background=[('active', '#0369a1'), ('disabled', '#475569')], foreground=[('disabled', '#94a3b8')])
        style.configure('Secondary.TButton', background='#334155', foreground='#ffffff', padding=(8, 6))
        style.map('Secondary.TButton', background=[('active', '#475569')])
        style.configure('SetupRoot.TFrame', background='#18173d')
        style.configure('SetupCard.TFrame', background='#1f1e4b')
        style.configure('SetupTitle.TLabel', background='#1f1e4b', foreground='#ffffff', font=('Segoe UI', 22, 'bold'))
        style.configure('HeroTitle.TLabel', background='#18173d', foreground='#ffffff', font=('Segoe UI', 28, 'bold'))
        style.configure('HeroKicker.TLabel', background='#18173d', foreground='#38bdf8', font=('Segoe UI', 9, 'bold'))
        style.configure('HeroCopy.TLabel', background='#18173d', foreground='#cbd5e1', font=('Segoe UI', 11))
        style.configure('SetupSubtitle.TLabel', background='#1f1e4b', foreground='#94a3b8', font=('Segoe UI', 9))
        style.configure('CardNote.TLabel', background='#1f1e4b', foreground='#a5b4fc', font=('Segoe UI', 9, 'bold'))
        style.configure('SetupText.TLabel', background='#1f1e4b', foreground='#ffffff', font=('Segoe UI', 10, 'bold'))
        style.configure('Count.TButton', background='#334155', foreground='#ffffff', padding=(12, 7), font=('Segoe UI', 10, 'bold'))
        style.map('Count.TButton', background=[('active', '#475569')])
        style.configure('CountSelected.TButton', background='#0284c7', foreground='white', padding=(12, 7), font=('Segoe UI', 10, 'bold'))
        style.map('CountSelected.TButton', background=[('active', '#0369a1')])
        style.configure('SeatMode.TButton', background='#334155', foreground='#ffffff', padding=(8, 6), anchor='w')
        style.map('SeatMode.TButton', background=[('active', '#475569')])
        style.configure('Start.TButton', background='#059669', foreground='white', padding=(22, 10), font=('Segoe UI', 11, 'bold'))
        style.map('Start.TButton', background=[('active', '#047857')])
        style.configure('NavBar.TFrame', background='#141332')
        style.configure('Brand.TLabel', background='#141332', foreground='#ffffff', font=('Segoe UI', 15, 'bold'))
        style.configure('Nav.TButton', background='#141332', foreground='#cbd5e1', padding=(12, 6), font=('Segoe UI', 9, 'bold'))
        style.map('Nav.TButton', background=[('active', '#1f1e4b')], foreground=[('active', '#ffffff')])
        style.configure('NavActive.TButton', background='#f59e0b', foreground='#0f172a', padding=(12, 6), font=('Segoe UI', 9, 'bold'))
        style.map('NavActive.TButton', background=[('active', '#fbbf24')], foreground=[('active', '#0f172a')])
        style.configure('Results.Treeview', background='#1f1e4b', fieldbackground='#1f1e4b', foreground='#ffffff', rowheight=32, font=('Segoe UI', 10))
        style.configure('Results.Treeview.Heading', background='#334155', foreground='#ffffff', font=('Segoe UI', 9, 'bold'), padding=(6, 6))
        style.map('Results.Treeview', background=[('selected', '#0284c7')], foreground=[('selected', '#ffffff')])
        style.configure('Player.TFrame', background='#252458')
        style.configure('PlayerActive.TFrame', background='#1e3a5f')
        style.configure('PlayerName.TLabel', background='#252458', foreground='#ffffff', font=('Segoe UI', 10, 'bold'))
        style.configure('PlayerActiveName.TLabel', background='#1e3a5f', foreground='#38bdf8', font=('Segoe UI', 10, 'bold'))
        style.configure('PlayerMeta.TLabel', background='#252458', foreground='#94a3b8', font=('Segoe UI', 8))
        style.configure('PlayerActiveMeta.TLabel', background='#1e3a5f', foreground='#bae6fd', font=('Segoe UI', 8))

    def _build(self):
        self.nav_bar = ttk.Frame(self.root, style='NavBar.TFrame', padding=(20, 8))
        self.nav_bar.pack(fill='x')
        ttk.Label(self.nav_bar, text='🎲 AI LUDO', style='Brand.TLabel').pack(side='left', padx=(0, 20))

        self.nav_buttons = {}
        for label in reversed(('Setup', 'Game', 'Results')):
            page = label.lower()
            btn = ttk.Button(self.nav_bar, text=label, style='Nav.TButton', command=lambda p=page: self._navigate(p))
            btn.pack(side='right', padx=(6, 0))
            self.nav_buttons[page] = btn

        sound_text = '🔊 Sound: ON' if self.sound_enabled.get() else '🔇 Sound: OFF'
        self.sound_btn = ttk.Button(self.nav_bar, text=sound_text, style='Nav.TButton', command=self._toggle_sound)
        self.sound_btn.pack(side='right', padx=(0, 16))

        self.pages = {
            'setup': ttk.Frame(self.root, style='SetupRoot.TFrame'),
            'game': ttk.Frame(self.root, style='App.TFrame'),
            'results': ttk.Frame(self.root, style='SetupRoot.TFrame'),
        }
        self._build_setup_page(self.pages['setup'])
        self._build_game_page(self.pages['game'])
        self._build_results_page(self.pages['results'])
        self.active_page = None
        self._show_page('setup')

    def _toggle_sound(self):
        new_val = not self.sound_enabled.get()
        self.sound_enabled.set(new_val)
        self.sound_btn.configure(text='🔊 Sound: ON' if new_val else '🔇 Sound: OFF')

    def _build_setup_page(self, page):
        content = ttk.Frame(page, style='SetupRoot.TFrame', padding=(36, 20))
        content.pack(fill='both', expand=True)
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=1)
        content.grid_rowconfigure(0, weight=1)

        hero = ttk.Frame(content, style='SetupRoot.TFrame')
        hero.grid(row=0, column=0, sticky='nsew', padx=(0, 26))
        ttk.Label(hero, text='AUTHENTIC BOARD ARTWORK & ADVANCED AI', style='HeroKicker.TLabel').pack(anchor='w', pady=(14, 4))
        ttk.Label(hero, text='Roll. Move.\nRace to Victory.', style='HeroTitle.TLabel', justify='left').pack(anchor='w')
        ttk.Label(
            hero,
            text='Faithfully modeled after classic board game art with golden-rimmed 3D pawns, authentic entry arrows, star tiles, and Expecti-MCTS & Smart AI agents.',
            style='HeroCopy.TLabel',
            wraplength=420,
            justify='left',
        ).pack(anchor='w', pady=(10, 16))

        ttk.Label(hero, text='AI AGENT ROSTER', style='HeroKicker.TLabel').pack(anchor='w', pady=(0, 4))
        roster = (
            ('⚖️ Expectiminimax', 'Pruned game tree with transposition cache'),
            ('🔥 Tuned', 'Self-play simulated annealing optimized weights'),
            ('⚡ Greedy', 'Fast 1-ply baseline heuristic'),
            ('🎲 Random', 'Uniform random baseline mover'),
        )
        for name, desc in roster:
            row = ttk.Frame(hero, style='SetupRoot.TFrame')
            row.pack(anchor='w', fill='x', pady=2)
            ttk.Label(row, text=name, style='HeroKicker.TLabel', width=16).pack(side='left')
            ttk.Label(row, text=desc, style='HeroCopy.TLabel', font=('Segoe UI', 9)).pack(side='left')

        card = ttk.Frame(content, style='SetupCard.TFrame', padding=(24, 20))
        card.grid(row=0, column=1, sticky='new')
        ttk.Label(card, text='Configure Match', style='SetupTitle.TLabel').pack(anchor='w')
        ttk.Label(card, text='Choose seats, player types, and game rules.', style='SetupSubtitle.TLabel').pack(anchor='w', pady=(2, 14))

        ttk.Label(card, text='NUMBER OF PLAYERS', style='CardNote.TLabel').pack(anchor='w')
        count_row = ttk.Frame(card, style='SetupCard.TFrame')
        count_row.pack(anchor='w', pady=(6, 12))
        self.player_buttons = {}
        for count in (2, 3, 4):
            btn = ttk.Button(count_row, text=f'{count} players', command=lambda val=count: self._set_player_count(val))
            btn.pack(side='left', padx=(0, 8))
            self.player_buttons[count] = btn

        ttk.Label(card, text='SEAT ASSIGNMENTS', style='CardNote.TLabel').pack(anchor='w', pady=(0, 6))
        self.seat_rows = ttk.Frame(card, style='SetupCard.TFrame')
        self.seat_rows.pack(fill='x')
        self._refresh_setup_controls()

        btn_bar = ttk.Frame(card, style='SetupCard.TFrame')
        btn_bar.pack(fill='x', pady=(16, 0))
        btn_bar.grid_columnconfigure(0, weight=1)
        btn_bar.grid_columnconfigure(1, weight=1)
        ttk.Button(btn_bar, text='⚙️ Rule Variants', style='Secondary.TButton', command=self.configure_rules).grid(row=0, column=0, sticky='ew', padx=(0, 4))
        ttk.Button(btn_bar, text='Start Match ▶', style='Start.TButton', command=self.start_game).grid(row=0, column=1, sticky='ew', padx=(4, 0))

    def _refresh_setup_controls(self):
        for count, btn in self.player_buttons.items():
            btn.configure(style='CountSelected.TButton' if count == self.num_players.get() else 'Count.TButton')
        for child in self.seat_rows.winfo_children():
            child.destroy()
        for player in seats_for(self.num_players.get()):
            row = ttk.Frame(self.seat_rows, style='SetupCard.TFrame')
            row.pack(fill='x', pady=3)
            marker = tk.Canvas(row, width=22, height=22, bg='#1f1e4b', highlightthickness=0)
            marker.pack(side='left', padx=(2, 8))
            marker.create_oval(2, 2, 20, 20, fill=self.COLORS[player], outline='')
            ttk.Label(row, text=PLAYER_NAMES[player], style='SetupText.TLabel', width=10).pack(side='left')
            mode = self.seat_modes[player].get().title()
            btn = ttk.Button(row, text=f'{mode} ▾', style='SeatMode.TButton', width=18)
            btn.configure(command=lambda p=player, b=btn: self._choose_seat_mode(p, b))
            btn.pack(side='right', fill='x', expand=True)

    def _set_player_count(self, count):
        self.num_players.set(count)
        self._refresh_setup_controls()

    def _choose_seat_mode(self, player, button):
        menu = tk.Menu(self.root, tearoff=False)
        for mode in ('human', 'expectiminimax', 'tuned', 'greedy', 'random'):
            menu.add_command(label=mode.title(), command=lambda val=mode: self._set_seat_mode(player, val))
        menu.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())

    def _set_seat_mode(self, player, mode):
        self.seat_modes[player].set(mode)
        self._refresh_setup_controls()

    def _navigate(self, page):
        if page == 'game' and self.state is None:
            page = 'setup'
        self._show_page(page)

    def _show_page(self, page):
        for view in self.pages.values():
            view.pack_forget()
        self.pages[page].pack(fill='both', expand=True)
        self.active_page = page
        for name, button in self.nav_buttons.items():
            button.configure(style='NavActive.TButton' if name == page else 'Nav.TButton')

    def start_game(self):
        self._show_page('game')
        self.new_game()

    def configure_rules(self):
        dlg = tk.Toplevel(self.root)
        dlg.title('Game Rules & Variants')
        dlg.geometry('420x420')
        dlg.resizable(False, False)
        dlg.configure(bg='#1f1e4b')
        dlg.transient(self.root)
        dlg.grab_set()

        content = ttk.Frame(dlg, style='Panel.TFrame', padding=20)
        content.pack(fill='both', expand=True)
        ttk.Label(content, text='Rule Variants', style='Turn.TLabel', font=('Segoe UI', 15, 'bold')).pack(anchor='w')
        ttk.Label(content, text='Customize the gameplay mechanics to your preference.', style='Muted.TLabel').pack(anchor='w', pady=(2, 12))

        rules_list = (
            (self.rule_extra_six, 'Extra turn on rolling a 6', 'Rolling 6 grants another roll.'),
            (self.rule_extra_capture, 'Extra turn on capturing opponent', 'Sending an opponent token to yard grants a bonus roll.'),
            (self.rule_extra_home, 'Extra turn on token reaching Home', 'Reaching the goal square awards a bonus roll.'),
            (self.rule_three_sixes, 'Three 6s in a row forfeit turn', 'Rolling three consecutive sixes cancels the turn.'),
            (self.rule_exact_finish, 'Exact roll required to reach Home', 'Overshooting the finish square is not permitted.'),
            (self.rule_blocks, 'Blockades (doubles block opponents)', 'Two tokens of the same color form an impassable barrier.'),
        )
        for var, title, desc in rules_list:
            row = ttk.Frame(content, style='Panel.TFrame')
            row.pack(fill='x', pady=4)
            cb = ttk.Checkbutton(row, variable=var, text=title)
            cb.pack(anchor='w')
            ttk.Label(row, text=desc, style='Hint.TLabel').pack(anchor='w', padx=(22, 0))

        ttk.Button(content, text='Save Rules', style='Primary.TButton', command=dlg.destroy).pack(fill='x', pady=(16, 0))

    def _get_active_rules(self) -> Rules:
        return Rules(
            extra_turn_on_six=self.rule_extra_six.get(),
            extra_turn_on_capture=self.rule_extra_capture.get(),
            extra_turn_on_home=self.rule_extra_home.get(),
            three_sixes_forfeit=self.rule_three_sixes.get(),
            exact_finish=self.rule_exact_finish.get(),
            blocks=self.rule_blocks.get(),
        )

    def _build_game_page(self, page):
        header = ttk.Frame(page, style='Header.TFrame', padding=(18, 8))
        header.pack(fill='x')
        brand = ttk.Frame(header, style='Header.TFrame')
        brand.pack(side='left')
        ttk.Label(brand, text='MATCH OVERVIEW', style='HeaderTitle.TLabel').pack(anchor='w')
        self.match_caption = ttk.Label(brand, text='', style='HeaderSubtitle.TLabel')
        self.match_caption.pack(anchor='w')
        self.header_status = ttk.Label(header, text='', style='HeaderMeta.TLabel')
        self.header_status.pack(side='right')

        content = ttk.Frame(page, style='App.TFrame', padding=(10, 8, 10, 10))
        content.pack(fill='both', expand=True)
        content.grid_columnconfigure(0, weight=1)
        content.grid_rowconfigure(0, weight=1)

        board_panel = ttk.Frame(content, style='App.TFrame', padding=(0, 0, 8, 0))
        board_panel.grid(row=0, column=0, sticky='nsew')
        self.canvas = tk.Canvas(board_panel, width=580, height=620, bg=self.BACKGROUND, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Configure>', lambda _e: self.draw())
        self.canvas.bind('<Button-1>', self._select_board_token)
        self.canvas.bind('<Motion>', self._on_canvas_motion)

        # Right control panel
        panel_shell = ttk.Frame(content, style='Panel.TFrame', width=330)
        panel_shell.grid(row=0, column=1, sticky='nsew')
        panel_shell.grid_propagate(False)
        panel_shell.grid_rowconfigure(0, weight=1)
        panel_shell.grid_columnconfigure(0, weight=1)

        panel_scroll = tk.Canvas(panel_shell, width=330, bg='#1f1e4b', highlightthickness=0, borderwidth=0)
        panel_scroll.grid(row=0, column=0, sticky='nsew')
        panel_scrollbar = ttk.Scrollbar(panel_shell, orient='vertical', command=panel_scroll.yview)
        panel_scrollbar.grid(row=0, column=1, sticky='ns')
        panel_scroll.configure(yscrollcommand=panel_scrollbar.set)

        panel = ttk.Frame(panel_scroll, style='Panel.TFrame', padding=12, width=330)
        panel_window = panel_scroll.create_window((0, 0), window=panel, anchor='nw')

        def update_panel_scroll(_e=None):
            panel_scroll.configure(scrollregion=panel_scroll.bbox('all'))
            panel_width = max(panel_shell.winfo_width() - 16, 290)
            panel_scroll.itemconfigure(panel_window, width=panel_width)

        panel.bind('<Configure>', update_panel_scroll)
        panel_shell.bind('<Configure>', update_panel_scroll)

        def scroll_panel(event):
            panel_scroll.yview_scroll(-1 if event.delta > 0 else 1, 'units')

        panel_scroll.bind('<Enter>', lambda _e: panel_scroll.bind_all('<MouseWheel>', scroll_panel))
        panel_scroll.bind('<Leave>', lambda _e: panel_scroll.unbind_all('<MouseWheel>'))

        # Match Controls
        ttk.Label(panel, text='MATCH CONTROLS', style='Section.TLabel').pack(anchor='w', pady=(0, 2))
        ctrl_grid = ttk.Frame(panel, style='Panel.TFrame')
        ctrl_grid.pack(fill='x', pady=(0, 4))
        ctrl_grid.grid_columnconfigure(0, weight=1)
        ctrl_grid.grid_columnconfigure(1, weight=1)

        ttk.Label(ctrl_grid, text='Watch Speed', style='Muted.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(ctrl_grid, text='Watch AI Agent', style='Muted.TLabel').grid(row=0, column=1, sticky='w')
        ttk.Combobox(ctrl_grid, textvariable=self.speed_var, values=tuple(self.SPEEDS.keys()), state='readonly').grid(row=1, column=0, sticky='ew', padx=(0, 4), pady=(2, 4))
        ttk.Combobox(ctrl_grid, textvariable=self.agent_name, values=self.AGENT_OPTIONS, state='readonly').grid(row=1, column=1, sticky='ew', padx=(4, 0), pady=(2, 4))

        self.watch_button = ttk.Button(panel, text='▶ Watch All-AI Match', style='Primary.TButton', command=self.toggle_auto)
        self.watch_button.pack(fill='x', pady=(2, 6))

        # Players Box
        ttk.Separator(panel).pack(fill='x', pady=(4, 6))
        ttk.Label(panel, text='PLAYERS & PROGRESS', style='Section.TLabel').pack(anchor='w', pady=(0, 4))
        self.player_list = ttk.Frame(panel, style='Panel.TFrame')
        self.player_list.pack(fill='x')
        for player in range(4):
            row = ttk.Frame(self.player_list, style='Player.TFrame', padding=5)
            marker = tk.Canvas(row, width=20, height=20, bg='#252458', highlightthickness=0)
            marker.pack(side='left', padx=(0, 8))
            marker.create_oval(2, 2, 18, 18, fill=self.COLORS[player], outline='')
            info = ttk.Frame(row, style='Player.TFrame')
            info.pack(side='left', fill='x', expand=True)
            name = ttk.Label(info, text=PLAYER_NAMES[player], style='PlayerName.TLabel')
            name.pack(anchor='w')
            mode = ttk.Label(info, text='', style='PlayerMeta.TLabel')
            mode.pack(anchor='w')
            stats_lbl = ttk.Label(row, text='0/4 Home', style='PlayerMeta.TLabel')
            stats_lbl.pack(side='right', padx=(4, 0))
            self.player_rows[player] = (row, marker, info, name, mode, stats_lbl)

        # Current Turn & Graphical Die
        ttk.Separator(panel).pack(fill='x', pady=(4, 6))
        ttk.Label(panel, text='CURRENT TURN', style='Section.TLabel').pack(anchor='w')
        self.status = ttk.Label(panel, text='', style='Turn.TLabel', wraplength=280)
        self.status.pack(anchor='w', pady=(2, 4))

        dice_card = ttk.Frame(panel, style='Panel.TFrame')
        dice_card.pack(fill='x', pady=(2, 6))
        self.dice_canvas = tk.Canvas(dice_card, width=54, height=54, bg='#1f1e4b', highlightthickness=0, cursor='hand2')
        self.dice_canvas.pack(side='left', padx=(4, 12))
        self.dice_canvas.bind('<Button-1>', lambda _e: self.roll())
        self._draw_die_face(None)

        dice_btn_frame = ttk.Frame(dice_card, style='Panel.TFrame')
        dice_btn_frame.pack(side='left', fill='x', expand=True)
        self.roll_button = ttk.Button(dice_btn_frame, text='🎲 Roll Dice', style='Primary.TButton', command=self.roll)
        self.roll_button.pack(fill='x')

        ttk.Label(panel, text='LEGAL MOVES', style='Section.TLabel').pack(anchor='w', pady=(4, 2))
        self.choice = ttk.Combobox(panel, state='readonly')
        self.choice.pack(fill='x', pady=(0, 4))
        self.choice.bind('<<ComboboxSelected>>', self._on_combobox_select)

        self.move_hint = ttk.Label(panel, text='Roll dice to see available moves.', style='Hint.TLabel', wraplength=280)
        self.move_hint.pack(anchor='w', pady=(0, 4))

        move_btn_row = ttk.Frame(panel, style='Panel.TFrame')
        move_btn_row.pack(fill='x', pady=(0, 4))
        move_btn_row.grid_columnconfigure(0, weight=2)
        move_btn_row.grid_columnconfigure(1, weight=1)
        self.move_button = ttk.Button(move_btn_row, text='Move Token', style='Primary.TButton', command=self.move_selected, state='disabled')
        self.move_button.grid(row=0, column=0, sticky='ew', padx=(0, 4))
        self.undo_button = ttk.Button(move_btn_row, text='↶ Undo', style='Secondary.TButton', command=self.undo_move, state='disabled')
        self.undo_button.grid(row=0, column=1, sticky='ew', padx=(4, 0))

        # Match Log
        ttk.Separator(panel).pack(fill='x', pady=6)
        ttk.Label(panel, text='LIVE MATCH LOG', style='Section.TLabel').pack(anchor='w', pady=(0, 2))
        self.log_box = tk.Text(panel, height=5, width=30, bg='#141332', fg='#e2e8f0', font=('Consolas', 9), relief='flat', padx=6, pady=6)
        self.log_box.pack(fill='x', pady=(0, 6))
        self.log_box.configure(state='disabled')

        self.details = ttk.Label(panel, text='', style='Muted.TLabel', wraplength=280, justify='left')
        self.details.pack(anchor='w', pady=(0, 4))

        self.actions = ttk.Frame(panel, style='Panel.TFrame')
        self.actions.pack(fill='x', pady=(4, 6))
        self.actions.grid_columnconfigure(0, weight=1)
        self.actions.grid_columnconfigure(1, weight=1)
        ttk.Button(self.actions, text='🔄 New Game', style='Secondary.TButton', command=self.new_game).grid(row=0, column=0, sticky='ew', padx=(0, 3))
        ttk.Button(self.actions, text='👥 Seats & AI', style='Secondary.TButton', command=self.configure_seats).grid(row=0, column=1, sticky='ew', padx=(3, 0))

    def _draw_die_face(self, val: Optional[int]):
        self.dice_canvas.delete('all')
        w, h = 54, 54
        # Rounded 3D die card
        self.dice_canvas.create_rectangle(5, 5, w - 1, h - 1, fill='#0f172a', outline='')
        self.dice_canvas.create_rectangle(3, 3, w - 3, h - 3, fill='#ffffff', outline='#94a3b8', width=2)

        if val is None:
            self.dice_canvas.create_text(w / 2, h / 2, text='?', fill='#94a3b8', font=('Segoe UI', 18, 'bold'))
            return

        cx, cy = w / 2, h / 2
        d = 12
        r = 3.5
        dot_positions = {
            'c': (cx, cy),
            'tl': (cx - d, cy - d),
            'tr': (cx + d, cy - d),
            'ml': (cx - d, cy),
            'mr': (cx + d, cy),
            'bl': (cx - d, cy + d),
            'br': (cx + d, cy + d),
        }

        face_map = {
            1: ['c'],
            2: ['tl', 'br'],
            3: ['tl', 'c', 'br'],
            4: ['tl', 'tr', 'bl', 'br'],
            5: ['tl', 'tr', 'c', 'bl', 'br'],
            6: ['tl', 'tr', 'ml', 'mr', 'bl', 'br'],
        }

        pip_fill = '#0f172a' if val != 6 else '#e52521'
        for dot_key in face_map.get(val, []):
            x, y = dot_positions[dot_key]
            self.dice_canvas.create_oval(x - r, y - r, x + r, y + r, fill=pip_fill, outline='')

    def _log_event(self, msg: str):
        self.log_box.configure(state='normal')
        self.log_box.insert('end', msg + '\n')
        self.log_box.see('end')
        self.log_box.configure(state='disabled')

    def _build_results_page(self, page):
        content = ttk.Frame(page, style='SetupRoot.TFrame', padding=(30, 20))
        content.pack(fill='both', expand=True)

        card = ttk.Frame(content, style='SetupCard.TFrame', padding=20)
        card.pack(anchor='n', fill='x')
        ttk.Label(card, text='Benchmarking & Analytics', style='SetupTitle.TLabel').pack(anchor='w')
        ttk.Label(card, text='Comparative agent win share across comprehensive tournament runs.', style='SetupSubtitle.TLabel').pack(anchor='w', pady=(2, 14))

        table = ttk.Treeview(card, columns=('agent', 'type', 'two', 'four', 'speed'), show='headings', height=6, style='Results.Treeview', selectmode='browse')
        table.heading('agent', text='Agent Name')
        table.heading('type', text='Algorithm')
        table.heading('two', text='2 Players Win %')
        table.heading('four', text='4 Players Win %')
        table.heading('speed', text='Move Latency')
        table.column('agent', width=160, anchor='w')
        table.column('type', width=220, anchor='w')
        table.column('two', width=140, anchor='center')
        table.column('four', width=140, anchor='center')
        table.column('speed', width=130, anchor='center')

        benchmarks = (
            ('Tuned', 'Self-Play Simulated Annealing', '61.2%', '27.6%', '0.4 ms'),
            ('Greedy', 'Baseline 1-Ply Heuristic', '56.8%', '28.2%', '0.3 ms'),
            ('Expectiminimax', 'Depth-2 Game Tree Search', '52.0%', '33.0%', '1.2 ms'),
            ('Random', 'Uniform Random Baseline', '16.2%', '11.2%', '0.03 ms'),
        )
        for idx, row in enumerate(benchmarks):
            table.insert('', 'end', values=row, tags=('even' if idx % 2 == 0 else 'odd',))
        table.tag_configure('even', background='#1f1e4b')
        table.tag_configure('odd', background='#252458')
        table.pack(anchor='w', fill='x')

        ttk.Label(card, text='Run experiments.tournament in PowerShell to execute customized headless benchmarks.', style='SetupSubtitle.TLabel').pack(anchor='w', pady=(14, 0))

    def new_game(self):
        if self.ai_turn_id is not None:
            self.root.after_cancel(self.ai_turn_id)
            self.ai_turn_id = None
        if self.dice_animation_id is not None:
            self.root.after_cancel(self.dice_animation_id)
            self.dice_animation_id = None

        self.is_rolling = False
        self.auto = False
        self.paused = False
        self.history.clear()
        self.selected_token = None
        self.watch_button.configure(text='▶ Watch All-AI Match')

        try:
            self.state = new_game(self.num_players.get(), rules=self._get_active_rules())
        except ValueError as error:
            messagebox.showerror('Invalid Setup', str(error))
            return

        self.dice = None
        self._draw_die_face(None)
        self.moves = []
        self.choice['values'] = ()
        self.choice.set('')
        self.move_button.configure(text='Move Token', state='disabled')
        self.undo_button.configure(state='disabled')
        self.move_hint.configure(text='Roll dice to see available moves.')
        self.details.configure(text='')

        self.log_box.configure(state='normal')
        self.log_box.delete('1.0', 'end')
        self.log_box.configure(state='disabled')
        self._log_event(f'🎮 New {len(self.state.players)}-Player Game Started!')

        self._update_status()
        self.draw()
        self._advance_if_needed()

    def current_is_human(self):
        return self.seat_modes[self.state.turn].get() == 'human'

    def configure_seats(self):
        dlg = tk.Toplevel(self.root)
        dlg.title('Player Roles & AI Configuration')
        dlg.geometry('420x460')
        dlg.resizable(False, False)
        dlg.configure(bg='#1f1e4b')
        dlg.transient(self.root)
        dlg.grab_set()

        content = ttk.Frame(dlg, style='Panel.TFrame', padding=20)
        content.pack(fill='both', expand=True)
        ttk.Label(content, text='Seat Controls', style='Turn.TLabel', font=('Segoe UI', 15, 'bold')).pack(anchor='w')
        ttk.Label(content, text='Choose who controls each player seat.', style='Muted.TLabel').pack(anchor='w', pady=(2, 14))

        modes = ('human', 'expectiminimax', 'tuned', 'greedy', 'random')
        for player in range(4):
            row = ttk.Frame(content, style='Player.TFrame', padding=(10, 6))
            row.pack(fill='x', pady=3)
            marker = tk.Canvas(row, width=22, height=22, bg='#252458', highlightthickness=0)
            marker.pack(side='left', padx=(0, 8))
            marker.create_oval(2, 2, 20, 20, fill=self.COLORS[player], outline='')
            ttk.Label(row, text=PLAYER_NAMES[player], style='SetupText.TLabel', width=8).pack(side='left')
            ttk.Combobox(
                row,
                textvariable=self.seat_modes[player],
                values=modes,
                state='readonly',
                width=16,
            ).pack(side='right')

        ttk.Button(content, text='Done', style='Primary.TButton', command=lambda: (dlg.destroy(), self._update_status())).pack(fill='x', pady=(16, 0))

    def roll(self):
        if self.state is None or self.state.is_terminal() or self.moves or self.is_rolling or self.dice is not None:
            return
        if self.ai_turn_id is not None:
            self.root.after_cancel(self.ai_turn_id)
            self.ai_turn_id = None
        self._roll_for_turn()

    def _roll_for_turn(self):
        if self.state is None or self.state.is_terminal() or self.is_rolling or self.dice is not None:
            self._update_status()
            return
        self.dice = roll_dice()
        result = self.dice
        player = self.state.turn
        self.is_rolling = True
        self.roll_button.configure(state='disabled')
        self.status.configure(text=f'{PLAYER_NAMES[player]} is rolling...')
        self._play_sound('roll')
        self._animate_dice(result, 6)

    def _animate_dice(self, result, frames_left):
        if frames_left:
            self._draw_die_face(roll_dice())
            self.dice_animation_id = self.root.after(65, lambda: self._animate_dice(result, frames_left - 1))
            return
        self.dice_animation_id = None
        self._draw_die_face(result)
        self.is_rolling = False
        self._resolve_roll()

    def _resolve_roll(self):
        player = self.state.turn
        p_name = PLAYER_NAMES[player]
        self.moves = get_legal_moves(self.state, self.dice)

        if not self.moves:
            d = self.dice
            self.dice = None
            if self.state.rules.three_sixes_forfeit and d == 6 and self.state.sixes >= 2:
                msg = f'⚠️ {p_name} rolled three 6s! Turn forfeited.'
            else:
                msg = f'🎲 {p_name} rolled {d}; no legal moves.'
            self._log_event(msg)
            self.state = pass_turn(self.state)
            self._update_status()
            self.status.configure(text=msg)
            self.move_hint.configure(text='No legal moves. Turn passed.')
            speed_delay = self.SPEEDS.get(self.speed_var.get(), 350)
            self.root.after(int(speed_delay * 0.8), self._advance_if_needed)
            self.draw()
            return

        if not self.current_is_human() or self.auto:
            mode = self.seat_modes[player].get()
            if self.auto and mode == 'human':
                mode = self.agent_name.get()
            agent = create_agent(mode, depth=self.depth.get())
            decision = agent.choose_move(self.state, self.dice)
            self.details.configure(text=f'AI ({mode}) evaluated {decision.nodes} nodes | score {decision.score:.2f}')
            self.status.configure(text=f'{p_name} rolled {self.dice}. {mode.upper()} moving...')
            self.move_hint.configure(text=f'{mode.title()} is executing move.')
            self.selected_token = decision.move.token if decision.move else None
            self.draw()
            speed_delay = self.SPEEDS.get(self.speed_var.get(), 350)
            self.dice_animation_id = self.root.after(speed_delay, lambda: self._finish_ai_move(decision.move))
            return

        # Human turn
        self.choice['values'] = tuple(
            f'Token {m.token + 1}: {m.src} -> {m.dst}' + (' ⚔️ capture' if m.captured else '') + (' ★ finish' if m.finishes else '')
            for m in self.moves
        )
        self.choice.current(0)
        self.selected_token = self.moves[0].token
        self.move_button.configure(state='normal')
        self.status.configure(text=f'{p_name} rolled {self.dice}. Click a highlighted piece or Move Token!')
        self.move_hint.configure(text='Select piece on board or from the dropdown.')
        self.draw()

    def _finish_ai_move(self, move):
        self.dice_animation_id = None
        self._apply(move)

    def _on_combobox_select(self, _e=None):
        idx = self.choice.current()
        if 0 <= idx < len(self.moves):
            self.selected_token = self.moves[idx].token
            self.draw()

    def move_selected(self):
        idx = self.choice.current()
        if 0 <= idx < len(self.moves):
            self._apply(self.moves[idx])

    def _on_canvas_motion(self, event):
        if not self.moves or not self.current_is_human() or self.auto:
            self.canvas.configure(cursor='')
            return
        legal_tokens = {m.token for m in self.moves}
        for x, y, radius, player, token in reversed(self.token_hitboxes):
            if player == self.state.turn and token in legal_tokens:
                if (event.x - x) ** 2 + (event.y - y) ** 2 <= radius ** 2:
                    self.canvas.configure(cursor='hand2')
                    return
        self.canvas.configure(cursor='')

    def _select_board_token(self, event):
        if not self.moves or not self.current_is_human() or self.auto:
            return
        legal_tokens = {m.token for m in self.moves}
        for x, y, radius, player, token in reversed(self.token_hitboxes):
            if player != self.state.turn:
                continue
            # Also allow clicking equivalent token in the same tile (e.g. yard)
            if token not in legal_tokens:
                token_src = self.state.pos[player][token]
                equiv_move = next((m for m in self.moves if m.src == token_src), None)
                if equiv_move is None:
                    continue
                match_token = equiv_move.token
            else:
                match_token = token

            if (event.x - x) ** 2 + (event.y - y) ** 2 > radius ** 2:
                continue

            move_idx = next(i for i, m in enumerate(self.moves) if m.token == match_token)
            
            # If clicked already-selected token, apply the move immediately!
            if self.selected_token == match_token:
                self._apply(self.moves[move_idx])
                return

            self.choice.current(move_idx)
            self.selected_token = match_token
            self.move_button.configure(text=f'Move Token {match_token + 1}')
            self.status.configure(text=f'Token {match_token + 1} selected! Click again or press Space to move.')
            self.draw()
            return

    def _apply(self, move):
        if move is None:
            return

        if self.current_is_human() and not self.auto:
            self.history.append((self.state, self.dice, self.moves))
            self.undo_button.configure(state='normal')

        p = self.state.turn
        p_name = PLAYER_NAMES[p]

        if move.enters:
            self._log_event(f'🚀 {p_name} Token {move.token + 1} left yard to start square.')
        elif move.finishes:
            self._log_event(f'🎉 {p_name} Token {move.token + 1} reached HOME!')
            self._play_sound('home')
        elif move.captured:
            victims = ', '.join(f"{PLAYER_NAMES[q]}'s token" for q, _ in move.captured)
            self._log_event(f'⚔️ {p_name} Token {move.token + 1} captured {victims}!')
            self._play_sound('capture')
        else:
            self._log_event(f'➡️ {p_name} Token {move.token + 1} moved {move.src} -> {move.dst}.')
            self._play_sound('move')

        prev_turn = self.state.turn
        self.state = apply_move(self.state, move)
        self.dice = None
        self._draw_die_face(None)
        self.moves = []
        self.selected_token = None
        self.choice.set('')
        self.choice['values'] = ()
        self.move_button.configure(text='Move Token', state='disabled')
        self.move_hint.configure(text='Roll dice to see available moves.')

        if not self.state.is_terminal() and self.state.turn == prev_turn:
            self._log_event(f'🔁 {p_name} earned an Extra Turn!')

        self._update_status()
        self.draw()

        speed_delay = self.SPEEDS.get(self.speed_var.get(), 350)
        self.root.after(int(speed_delay * 0.7), self._advance_if_needed)

    def undo_move(self):
        if not self.history or self.is_rolling:
            return
        self.state, self.dice, self.moves = self.history.pop()
        if not self.history:
            self.undo_button.configure(state='disabled')
        self._draw_die_face(self.dice)
        self.selected_token = None
        self._log_event('↶ Move undone.')
        self._update_status()
        self.draw()

    def _advance_if_needed(self):
        if self.state is None:
            return
        if self.state.is_terminal():
            self.auto = False
            self.watch_button.configure(text='▶ Watch All-AI Match')
            self._play_sound('win')
            self._update_status()
            return
        if not self.paused and (self.auto or not self.current_is_human()):
            if self.ai_turn_id is None:
                delay = self.SPEEDS.get(self.speed_var.get(), 350)
                self.ai_turn_id = self.root.after(delay, self._run_scheduled_turn)

    def _run_scheduled_turn(self):
        self.ai_turn_id = None
        if self.state is not None and not self.state.is_terminal() and not self.paused:
            if self.auto or not self.current_is_human():
                self._roll_for_turn()

    def toggle_auto(self):
        if self.ai_turn_id is not None:
            self.root.after_cancel(self.ai_turn_id)
            self.ai_turn_id = None
        if self.auto:
            self.auto = False
            self.paused = True
            self.watch_button.configure(text='▶ Resume Watch')
            return
        self.auto = True
        self.paused = False
        self.watch_button.configure(text='⏸ Pause Watch')
        if self.auto:
            self._roll_for_turn()

    def _update_status(self):
        winner = self.state.winner()
        active_rules = []
        if self.state.rules.blocks:
            active_rules.append('Blockades')
        if self.state.rules.exact_finish:
            active_rules.append('Exact Finish')
        rules_text = ' & '.join(active_rules) if active_rules else 'Standard Rules'
        self.match_caption.configure(text=f'{len(self.state.players)} Players  |  {rules_text}')

        if winner is not None:
            w_name = PLAYER_NAMES[winner]
            self.header_status.configure(text=f'👑 {w_name.upper()} WINS!')
            self.status.configure(text=f'🏆 {w_name} has won the match!')
            self.roll_button.configure(text='Game Over', state='disabled')
        else:
            human_turn = self.current_is_human()
            mode = self.seat_modes[self.state.turn].get()
            p_name = PLAYER_NAMES[self.state.turn]
            self.header_status.configure(text=f'{p_name.upper()} TO PLAY')
            self.status.configure(text=f'{p_name} to play ({mode.title()}).')
            self.roll_button.configure(
                text='🎲 Roll Dice' if human_turn else '▶ Run AI Turn',
                state='disabled' if self.moves or self.is_rolling else 'normal',
            )
        self._update_player_rows(winner)

    def _update_player_rows(self, winner):
        for row, _, _, _, _, _ in self.player_rows.values():
            row.pack_forget()
        active = winner if winner is not None else self.state.turn
        for p in self.state.players:
            row, marker, info, name, mode, stats_lbl = self.player_rows[p]
            is_active = p == active
            r_style = 'PlayerActive.TFrame' if is_active else 'Player.TFrame'
            m_style = 'PlayerActiveMeta.TLabel' if is_active else 'PlayerMeta.TLabel'
            row.configure(style=r_style)
            info.configure(style=r_style)
            marker.configure(bg='#1e3a5f' if is_active else '#252458')
            name.configure(style='PlayerActiveName.TLabel' if is_active else 'PlayerName.TLabel', text=PLAYER_NAMES[p])
            mode_name = 'Human Player' if self.seat_modes[p].get() == 'human' else f'{self.seat_modes[p].get().title()} AI'
            mode.configure(style=m_style, text=mode_name)
            finished = sum(pos == HOME for pos in self.state.pos[p])
            stats_lbl.configure(style=m_style, text=f'{finished}/4 Home')
            row.pack(fill='x', pady=2)

    def _draw_star_polygon(self, cx, cy, r_out, r_in, fill='#ffffff', outline='', width=1):
        points = []
        for i in range(10):
            r = r_out if i % 2 == 0 else r_in
            angle = -math.pi / 2 + i * math.pi / 5
            points.append(cx + r * math.cos(angle))
            points.append(cy + r * math.sin(angle))
        self.canvas.create_polygon(points, fill=fill, outline=outline, width=width)

    def _draw_rounded_rect(self, x1, y1, x2, y2, radius, fill, outline='', width=1):
        radius = min(radius, (x2 - x1) / 2, (y2 - y1) / 2)
        points = (
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        )
        self.canvas.create_polygon(points, smooth=True, fill=fill, outline=outline or fill, width=width)

    def _draw_arrow(self, r, c, direction, color, cell, left, top):
        x1 = left + c * cell
        y1 = top + r * cell
        cx = x1 + cell / 2
        cy = y1 + cell / 2
        d = cell * 0.28
        h = cell * 0.32

        if direction == 'right':
            pts = (cx - h / 2, cy - d, cx + h / 2, cy, cx - h / 2, cy + d)
        elif direction == 'down':
            pts = (cx - d, cy - h / 2, cx, cy + h / 2, cx + d, cy - h / 2)
        elif direction == 'left':
            pts = (cx + h / 2, cy - d, cx - h / 2, cy, cx + h / 2, cy + d)
        elif direction == 'up':
            pts = (cx - d, cy + h / 2, cx, cy - h / 2, cx + d, cy + h / 2)
        else:
            return

        self.canvas.create_polygon(*pts, fill=color, outline='')

    def _draw_pawn_badge(self, cx, cy, radius, player, label_text='', is_legal=False, is_selected=False):
        # Drop shadow
        self.canvas.create_oval(cx - radius + 1, cy - radius + 2, cx + radius + 1, cy + radius + 2, fill='#0f172a', outline='')

        # Legal or selected highlight glow
        if is_legal:
            glow = '#38bdf8' if is_selected else '#fef08a'
            self.canvas.create_oval(cx - radius * 1.35, cy - radius * 1.35, cx + radius * 1.35, cy + radius * 1.35, fill='', outline=glow, width=3)

        # Outer gold metallic rim (just like reference image pawns)
        self.canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, fill=self.GOLD_RIM, outline=self.GOLD_RIM_DARK, width=1.5)

        # Body in player color
        inner_r = radius * 0.78
        self.canvas.create_oval(cx - inner_r, cy - inner_r, cx + inner_r, cy + inner_r, fill=self.COLORS[player], outline='')

        # Top gloss shine
        shine_r = inner_r * 0.45
        self.canvas.create_oval(cx - inner_r * 0.5, cy - inner_r * 0.7, cx - inner_r * 0.5 + shine_r, cy - inner_r * 0.7 + shine_r * 0.7, fill='#ffffff', outline='')

        # Center white star or token number
        core_r = inner_r * 0.52
        self.canvas.create_oval(cx - core_r, cy - core_r, cx + core_r, cy + core_r, fill='#ffffff', outline='')

        if label_text:
            self.canvas.create_text(cx, cy, text=label_text, fill=self.COLORS[player], font=('Segoe UI', max(7, int(radius * 0.65)), 'bold'))
        else:
            self._draw_star_polygon(cx, cy, core_r * 0.85, core_r * 0.40, fill=self.COLORS[player], outline='')

    def draw(self):
        if self.state is None:
            return
        self.canvas.delete('all')
        self.token_hitboxes = []

        width = max(self.canvas.winfo_width(), 520)
        height = max(self.canvas.winfo_height(), 520)

        # Allow vertical room for the bottom pawn tray
        board_size = max(min(width - 32, height - 90), 400)
        cell = board_size / 15
        left = (width - board_size) / 2
        top = max(10.0, (height - board_size - 60) / 2)

        def bounds(r, c):
            return left + c * cell, top + r * cell, left + (c + 1) * cell, top + (r + 1) * cell

        def center(r, c):
            x1, y1, x2, y2 = bounds(r, c)
            return (x1 + x2) / 2, (y1 + y2) / 2

        def fill_cell(r, c, fill, outline=self.GRID_LINE, width=1):
            self.canvas.create_rectangle(*bounds(r, c), fill=fill, outline=outline, width=width)

        # 1. Outer rounded peach-caramel wooden frame (matching reference image)
        frame_pad = cell * 0.40
        self._draw_rounded_rect(
            left - frame_pad,
            top - frame_pad,
            left + board_size + frame_pad,
            top + board_size + frame_pad,
            cell * 0.85,
            self.FRAME_COLOR,
            self.FRAME_BORDER,
            2,
        )

        # 2. Main white board background
        self.canvas.create_rectangle(left, top, left + board_size, top + board_size, fill=self.BOARD_WHITE, outline='')

        # 3. Base quadrants & Yards
        for player, (base_r, base_c) in enumerate(self.BASE_ORIGINS):
            bx1 = left + base_c * cell
            by1 = top + base_r * cell
            bx2 = bx1 + 6 * cell
            by2 = by1 + 6 * cell
            # Solid quadrant background
            self.canvas.create_rectangle(bx1, by1, bx2, by2, fill=self.COLORS[player], outline='')

            # Inner rounded rectangle (lighter tone)
            pad = cell * 0.80
            self._draw_rounded_rect(bx1 + pad, by1 + pad, bx2 - pad, by2 - pad, cell * 0.40, self.YARD_INNER_COLORS[player], outline='')

            # Active player highlight glow
            if self.state.winner() is None and player == self.state.turn:
                self._draw_rounded_rect(bx1 + pad - 2, by1 + pad - 2, bx2 - pad + 2, by2 - pad + 2, cell * 0.45, '', '#ffffff', 2)

            # 4 darker circular pockets
            for r, c in YARD_COORDS[player]:
                px, py = center(r, c)
                pocket_r = cell * 0.44
                self.canvas.create_oval(px - pocket_r, py - pocket_r, px + pocket_r, py + pocket_r, fill=self.YARD_POCKET_COLORS[player], outline='')

        # 4. Main track cells (crisp white with grid lines)
        for r, c in TRACK_COORDS:
            fill_cell(r, c, self.BOARD_WHITE)

        # 5. Start squares & Safe squares (Stars)
        for sq in SAFE_SQUARES:
            r, c = TRACK_COORDS[sq]
            cx, cy = center(r, c)

            if sq in START_SQUARE:
                # Start squares have that player's solid color
                p = START_SQUARE.index(sq)
                fill_cell(r, c, self.COLORS[p])
                # Star inside start square
                badge_r = cell * 0.35
                self.canvas.create_oval(cx - badge_r, cy - badge_r, cx + badge_r, cy + badge_r, fill='', outline='#ffffff', width=1.5)
                self._draw_star_polygon(cx, cy, badge_r * 0.85, badge_r * 0.38, fill='#ffffff')
            else:
                # Other 4 safe squares: tinted cell + colored circular badge with white star
                p = sq // 13
                fill_cell(r, c, self.STAR_CELL_COLORS[p])
                badge_r = cell * 0.35
                self.canvas.create_oval(cx - badge_r, cy - badge_r, cx + badge_r, cy + badge_r, fill=self.COLORS[p], outline='#ffffff', width=1)
                self._draw_star_polygon(cx, cy, badge_r * 0.75, badge_r * 0.32, fill='#ffffff')

        # 6. Directional track entry arrows
        for r, c, direction, arrow_color in self.ENTRY_ARROWS:
            fill_cell(r, c, self.BOARD_WHITE)
            self._draw_arrow(r, c, direction, arrow_color, cell, left, top)

        # 7. Home column lanes
        for player, lane in enumerate(HOME_COLUMN_COORDS):
            for r, c in lane:
                fill_cell(r, c, self.COLORS[player], outline='#ffffff', width=1)

        # 8. Center Home Triangles
        x0, y0 = left + 6 * cell, top + 6 * cell
        x3, y3 = x0 + 3 * cell, y0 + 3 * cell
        cx, cy = (x0 + x3) / 2, (y0 + y3) / 2
        triangles = (
            (self.COLORS[0], (x0, y0, x0, y3, cx, cy)),
            (self.COLORS[1], (x0, y0, x3, y0, cx, cy)),
            (self.COLORS[2], (x3, y0, x3, y3, cx, cy)),
            (self.COLORS[3], (x0, y3, x3, y3, cx, cy)),
        )
        for col, pts in triangles:
            self.canvas.create_polygon(*pts, fill=col, outline='#ffffff', width=1.5)

        # 9. Destination tile preview highlight
        if self.moves and self.selected_token is not None:
            sel_move = next((m for m in self.moves if m.token == self.selected_token), None)
            if sel_move:
                dest_sq = sel_move.dst
                if dest_sq == HOME:
                    dest_pos = (7, 7)
                elif on_track(dest_sq):
                    dest_pos = TRACK_COORDS[abs_square(self.state.turn, dest_sq)]
                elif HOME_COLUMN_START <= dest_sq < HOME:
                    dest_pos = HOME_COLUMN_COORDS[self.state.turn][dest_sq - HOME_COLUMN_START]
                else:
                    dest_pos = None

                if dest_pos:
                    dx1, dy1, dx2, dy2 = bounds(dest_pos[0], dest_pos[1])
                    pulse_color = '#ef4444' if sel_move.captured else ('#eab308' if sel_move.finishes else '#06b6d4')
                    self.canvas.create_rectangle(dx1 + 2, dy1 + 2, dx2 - 2, dy2 - 2, outline=pulse_color, width=4)
                    if sel_move.captured:
                        self.canvas.create_text((dx1 + dx2) / 2, (dy1 + dy2) / 2 - cell * 0.35, text='⚔️', font=('Segoe UI', 12))

        # 10. Draw tokens / pawns on the board
        occupants = {}
        for player in range(4):
            for token, rel in enumerate(self.state.pos[player]):
                if rel == YARD:
                    pos = YARD_COORDS[player][token]
                elif rel == HOME:
                    pos = (7, 7)
                elif on_track(rel):
                    pos = TRACK_COORDS[(START_SQUARE[player] + rel) % TRACK_LEN]
                elif HOME_COLUMN_START <= rel < HOME:
                    lane_idx = rel - HOME_COLUMN_START
                    pos = HOME_COLUMN_COORDS[player][lane_idx]
                else:
                    continue
                occupants.setdefault(pos, []).append((player, token))

        offsets = ((-0.18, -0.18), (0.18, -0.18), (-0.18, 0.18), (0.18, 0.18))
        legal_tokens = {m.token for m in self.moves}

        for (row, col), tokens in occupants.items():
            pcx, pcy = center(row, col)
            for idx, (player, token) in enumerate(tokens):
                dx, dy = offsets[idx % len(offsets)] if len(tokens) > 1 else (0, 0)
                radius = cell * 0.26
                token_x = pcx + dx * cell
                token_y = pcy + dy * cell
                self.token_hitboxes.append((token_x, token_y, radius * 1.5, player, token))

                is_legal = player == self.state.turn and token in legal_tokens
                is_selected = is_legal and token == self.selected_token
                self._draw_pawn_badge(
                    token_x,
                    token_y,
                    radius,
                    player,
                    label_text=str(token + 1),
                    is_legal=is_legal,
                    is_selected=is_selected,
                )

        # 11. Bottom tray of 4 pawns (Green, Red, Yellow, Blue matching reference artwork!)
        tray_y = top + board_size + cell * 0.72
        tray_x_start = left + board_size / 2 - 3 * cell * 0.55
        pawn_order = (1, 0, 2, 3)  # Green, Red, Yellow, Blue as shown in reference image
        for idx, player in enumerate(pawn_order):
            px = tray_x_start + idx * cell * 0.75
            self._draw_pawn_badge(px, tray_y, cell * 0.28, player, label_text='')
            finished = sum(pos == HOME for pos in self.state.pos[player])
            self.canvas.create_text(
                px, tray_y + cell * 0.38,
                text=f'{finished}/4',
                fill='#cbd5e1',
                font=('Segoe UI', max(7, int(cell * 0.16)), 'bold'),
            )

        # 12. Victory Card Overlay (when match ends)
        if self.state.winner() is not None:
            w_idx = self.state.winner()
            w_name = PLAYER_NAMES[w_idx]
            cx, cy = left + board_size / 2, top + board_size / 2
            cw, ch = cell * 7.0, cell * 3.4
            self._draw_rounded_rect(cx - cw / 2 + 3, cy - ch / 2 + 4, cx + cw / 2 + 3, cy + ch / 2 + 4, cell * 0.45, '#0f172a', '')
            self._draw_rounded_rect(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2, cell * 0.45, '#1f1e4b', self.GOLD_RIM, 3)
            self._draw_star_polygon(cx, cy - cell * 0.9, cell * 0.38, cell * 0.18, fill=self.GOLD_RIM)
            self.canvas.create_text(cx, cy - cell * 0.20, text=f'👑 {w_name.upper()} WINS!', fill='#ffffff', font=('Segoe UI', max(12, int(cell * 0.36)), 'bold'))
            self.canvas.create_text(cx, cy + cell * 0.45, text='All 4 tokens reached home!', fill='#a5b4fc', font=('Segoe UI', max(8, int(cell * 0.19))))
            self.canvas.create_text(cx, cy + cell * 0.95, text='Press New Game or Space to play again', fill='#fbbf24', font=('Segoe UI', max(7, int(cell * 0.16)), 'italic'))



def main():
    root = tk.Tk()
    LudoApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
