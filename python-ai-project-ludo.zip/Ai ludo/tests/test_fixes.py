import json
import random
import unittest

from agents.expectiminimax import ExpectiminimaxAgent
from agents.factory import create_agent
from board import YARD
from experiments.search_benchmark import sample_positions
from experiments.tournament import build_schedule, run_tournament
from rules import apply_move, get_legal_moves
from state import Rules, State


def make_state(pos0=(YARD,) * 4, pos2=(YARD,) * 4, rules=None):
    positions = (tuple(pos0), (YARD,) * 4, tuple(pos2), (YARD,) * 4)
    return State(positions, 0, 0, (0, 2), rules or Rules())


class SearchCorrectnessTests(unittest.TestCase):
    def check_matches_plain(self, players, depth, count, seed, **options):
        plain = ExpectiminimaxAgent(depth, prune=False, use_table=False)
        fast = ExpectiminimaxAgent(depth, **options)
        for state, dice in sample_positions(players, count, seed):
            expected = plain.choose_move(state, dice)
            actual = fast.choose_move(state, dice)
            self.assertAlmostEqual(actual.score, expected.score, places=6)
            self.assertEqual(actual.move, expected.move)

    def test_alpha_beta_with_table_matches_plain_depth_2(self):
        for players in (2, 4):
            self.check_matches_plain(players, 2, 25, 11)

    def test_alpha_beta_with_table_matches_plain_depth_3(self):
        for players in (2, 4):
            self.check_matches_plain(players, 3, 12, 21)

    def test_each_option_matches_plain(self):
        self.check_matches_plain(2, 3, 12, 31, use_table=False)
        self.check_matches_plain(2, 3, 12, 32, prune=False, use_table=True)
        self.check_matches_plain(2, 3, 12, 33, order_moves=False)

    def test_pruning_does_not_increase_nodes(self):
        plain = ExpectiminimaxAgent(3, prune=False, use_table=False)
        pruned = ExpectiminimaxAgent(3, prune=True, use_table=True)
        plain_nodes = pruned_nodes = 0
        for state, dice in sample_positions(2, 12, 41):
            plain_nodes += plain.choose_move(state, dice).nodes
            pruned_nodes += pruned.choose_move(state, dice).nodes
        self.assertLessEqual(pruned_nodes, plain_nodes)

    def test_table_only_holds_exact_values(self):
        agent = ExpectiminimaxAgent(3)
        for state, dice in sample_positions(2, 5, 51):
            agent.choose_move(state, dice)
            for value in agent._tt.values():
                self.assertGreaterEqual(value, agent.VALUE_FLOOR)
                self.assertLessEqual(value, agent.VALUE_LIMIT)


class ReproducibilityTests(unittest.TestCase):
    def test_seeded_random_agents_choose_identically(self):
        state = make_state(pos0=(5, 9, 20, YARD))
        first = create_agent('random', seed=7)
        second = create_agent('random', seed=7)
        for dice in (1, 2, 3, 4, 5, 6):
            self.assertEqual(first.choose_move(state, dice).move, second.choose_move(state, dice).move)

    def test_tournament_is_reproducible(self):
        results = [
            run_tournament(['random', 'greedy', 'tuned'], games=24, num_players=2, seed=3)
            for _ in range(2)
        ]
        self.assertEqual(results[0]['agent_metrics'].split('average_seconds_per_move')[0],
                         results[1]['agent_metrics'].split('average_seconds_per_move')[0])
        self.assertEqual(results[0]['pairwise'], results[1]['pairwise'])
        self.assertEqual(results[0]['wins'], results[1]['wins'])


class BalancedTournamentTests(unittest.TestCase):
    def test_round_robin_is_balanced(self):
        names = ['random', 'greedy', 'expectiminimax', 'tuned']
        schedule = build_schedule(names, 120, 2)
        self.assertEqual(len(schedule), 120)
        meetings = {}
        seats = {name: [0, 0] for name in names}
        for first, second in schedule:
            meetings[(first, second)] = meetings.get((first, second), 0) + 1
            seats[first][0] += 1
            seats[second][1] += 1
        self.assertEqual(len(meetings), 12)
        self.assertEqual(len(set(meetings.values())), 1)
        for name in names:
            self.assertEqual(seats[name][0], seats[name][1])

    def test_every_agent_meets_every_other_agent(self):
        result = run_tournament(['random', 'greedy', 'tuned'], games=12, num_players=2, seed=1)
        pairs = json.loads(result['pairwise'])
        self.assertEqual(set(pairs), {'greedy vs random', 'greedy vs tuned', 'random vs tuned'})
        self.assertEqual({entry['games'] for entry in pairs.values()}, {4})

    def test_four_player_rotation_gives_each_agent_every_seat(self):
        names = ['random', 'greedy', 'expectiminimax', 'tuned']
        schedule = build_schedule(names, 8, 4)
        for seat in range(4):
            self.assertEqual({game[seat] for game in schedule}, set(names))


class BlockRuleTests(unittest.TestCase):
    def test_block_stops_landing_and_passing(self):
        rules = Rules(blocks=True)
        state = make_state(pos0=(5, YARD, YARD, YARD), pos2=(33, 33, YARD, YARD), rules=rules)
        self.assertEqual(get_legal_moves(state, 2), [])
        self.assertEqual(get_legal_moves(state, 3), [])
        self.assertEqual(len(get_legal_moves(state, 1)), 1)

    def test_without_blocks_both_tokens_are_captured(self):
        state = make_state(pos0=(5, YARD, YARD, YARD), pos2=(33, 33, YARD, YARD))
        move = get_legal_moves(state, 2)[0]
        self.assertEqual(len(move.captured), 2)
        result = apply_move(state, move)
        self.assertEqual(result.pos[2][:2], (YARD, YARD))


class TunerTests(unittest.TestCase):
    def test_compare_weights_with_itself_is_near_half(self):
        from agents.heuristic import DEFAULT_WEIGHTS
        from optimization.tuner import compare_weights

        rate = compare_weights(DEFAULT_WEIGHTS, DEFAULT_WEIGHTS, games=200, seed=1)
        self.assertGreater(rate, 0.35)
        self.assertLess(rate, 0.65)

    def test_tuner_returns_valid_weights_with_final_check(self):
        from agents.heuristic import DEFAULT_WEIGHTS
        from optimization.tuner import tune_weights

        weights = tune_weights(DEFAULT_WEIGHTS, iterations=3, games_per_candidate=4, seed=2, final_games=20)
        self.assertTrue(all(value > 0 for value in weights.__dict__.values()))


if __name__ == '__main__':
    unittest.main()
