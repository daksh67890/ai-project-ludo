import unittest
import json
import tempfile
from pathlib import Path

from agents.expectiminimax import ExpectiminimaxAgent
from agents.factory import create_agent
from agents.greedy_agent import GreedyAgent
from agents.heuristic import evaluate
from agents.random_agent import RandomAgent
from experiments.tournament import run_tournament
from optimization.tuner import load_weights, save_weights, tune_weights
from rules import get_legal_moves
from state import new_game


class AgentTests(unittest.TestCase):
    def test_agents_choose_only_legal_moves(self):
        state = new_game(2)
        legal = get_legal_moves(state, 6)
        agents = (
            RandomAgent(),
            GreedyAgent(),
            ExpectiminimaxAgent(depth=1),
        )
        for agent in agents:
            self.assertIn(agent.choose_move(state, 6).move, legal)

    def test_agents_pass_when_no_moves(self):
        state = new_game(2)
        agents = (
            RandomAgent(),
            GreedyAgent(),
            ExpectiminimaxAgent(depth=1),
        )
        for agent in agents:
            self.assertIsNone(agent.choose_move(state, 2).move)

    def test_factory_creates_all_agents(self):
        for name in ('random', 'greedy', 'expectiminimax', 'tuned'):
            agent = create_agent(name)
            self.assertIsNotNone(agent)


    def test_expectiminimax_transposition_table(self):
        agent = ExpectiminimaxAgent(depth=2)
        state = new_game(2)
        decision = agent.choose_move(state, 6)
        self.assertIsNotNone(decision)
        # Verify cache was populated during search
        self.assertGreater(len(agent._tt), 0)

    def test_terminal_heuristic_prefers_winner(self):
        state = new_game(2)
        positions = [list(row) for row in state.pos]
        positions[0] = [56] * 4
        won = state._replace(pos=tuple(tuple(row) for row in positions))
        self.assertGreater(evaluate(won, 0), evaluate(won, 2))

    def test_tournament_completes_seeded_games(self):
        result = run_tournament(['random', 'greedy'], games=2, seed=10)
        self.assertEqual(result['completion_rate'], 1.0)
        self.assertEqual(sum(result['wins'].values()), 2)

    def test_tuner_returns_valid_weights(self):
        weights = tune_weights(iterations=1, games_per_candidate=1, seed=5)
        self.assertTrue(all(value >= 0 for value in weights.__dict__.values()))

    def test_tuned_weights_round_trip(self):
        weights = tune_weights(iterations=1, games_per_candidate=1, seed=6)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'weights.json'
            save_weights(weights, path)
            self.assertEqual(load_weights(path), weights)

    def test_tournament_reports_agent_metrics(self):
        result = run_tournament(['random', 'greedy'], games=2, seed=12)
        metrics = json.loads(result['agent_metrics'])
        self.assertEqual(set(metrics), {'random', 'greedy'})
        self.assertIn('average_seconds_per_move', metrics['greedy'])
        self.assertIn('captures_per_game', metrics['random'])


if __name__ == '__main__':
    unittest.main()