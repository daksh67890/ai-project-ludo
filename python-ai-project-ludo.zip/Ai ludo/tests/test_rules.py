import unittest

from board import HOME, HOME_COLUMN_COORDS, SAFE_SQUARES, START_SQUARE, TRACK_COORDS, TRACK_LEN, YARD, abs_square
from rules import apply_move, get_legal_moves, pass_turn
from state import Rules, State, new_game


def make_state(pos0=(YARD,) * 4, pos2=(YARD,) * 4, turn=0, sixes=0, rules=None):
    positions = (tuple(pos0), (YARD,) * 4, tuple(pos2), (YARD,) * 4)
    return State(positions, turn, sixes, (0, 2), rules or Rules())


class RulesTests(unittest.TestCase):
    def test_board_track_has_52_unique_connected_spaces(self):
        self.assertEqual(len(TRACK_COORDS), TRACK_LEN)
        self.assertEqual(len(set(TRACK_COORDS)), TRACK_LEN)
        for current, following in zip(TRACK_COORDS, TRACK_COORDS[1:] + TRACK_COORDS[:1]):
            distance = abs(current[0] - following[0]) + abs(current[1] - following[1])
            self.assertIn(distance, (1, 2))

    def test_start_squares_and_home_lanes_match_player_routes(self):
        for player, start in enumerate(START_SQUARE):
            self.assertEqual(TRACK_COORDS[start], ((6, 1), (1, 8), (8, 13), (13, 6))[player])
            last_track = TRACK_COORDS[(start + TRACK_LEN - 2) % TRACK_LEN]
            first_home = HOME_COLUMN_COORDS[player][0]
            distance = abs(last_track[0] - first_home[0]) + abs(last_track[1] - first_home[1])
            self.assertEqual(distance, 1)

    def test_six_is_required_to_leave_yard(self):
        state = new_game(2)
        self.assertEqual(get_legal_moves(state, 5), [])
        self.assertEqual(get_legal_moves(state, 6)[0].dst, 0)

    def test_capture_sends_token_home_and_grants_extra_turn(self):
        state = make_state(pos0=(5, YARD, YARD, YARD), pos2=(33, YARD, YARD, YARD))
        move = next(move for move in get_legal_moves(state, 2) if move.token == 0)
        result = apply_move(state, move)
        self.assertEqual(result.pos[2][0], YARD)
        self.assertEqual(result.turn, 0)

    def test_safe_square_prevents_capture(self):
        state = make_state(pos0=(6, YARD, YARD, YARD), pos2=(34, YARD, YARD, YARD))
        move = get_legal_moves(state, 2)[0]
        self.assertIn(abs_square(0, move.dst), SAFE_SQUARES)
        self.assertEqual(move.captured, ())

    def test_three_sixes_forfeit_turn(self):
        state = make_state(pos0=(10, YARD, YARD, YARD), sixes=2)
        self.assertEqual(get_legal_moves(state, 6), [])
        self.assertEqual(pass_turn(state).turn, 2)

    def test_exact_finish_rejects_overshoot(self):
        state = make_state(pos0=(54, YARD, YARD, YARD))
        self.assertEqual(get_legal_moves(state, 3), [])
        self.assertEqual(get_legal_moves(state, 2)[0].dst, HOME)


if __name__ == '__main__':
    unittest.main()