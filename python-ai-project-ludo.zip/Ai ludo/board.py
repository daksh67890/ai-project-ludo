TRACK_LEN = 52
TOKENS_PER_PLAYER = 4
YARD = -1
LAST_TRACK = 50
HOME_COLUMN_START = 51
HOME = 56
PLAYER_NAMES = ('Red', 'Green', 'Yellow', 'Blue')
START_SQUARE = (0, 13, 26, 39)
SAFE_SQUARES = frozenset({0, 8, 13, 21, 26, 34, 39, 47})
TRACK_COORDS = (
    (6, 1), (6, 2), (6, 3), (6, 4), (6, 5), (5, 6), (4, 6), (3, 6),
    (2, 6), (1, 6), (0, 6), (0, 7), (0, 8), (1, 8), (2, 8), (3, 8),
    (4, 8), (5, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13), (6, 14),
    (7, 14), (8, 14), (8, 13), (8, 12), (8, 11), (8, 10), (8, 9), (9, 8),
    (10, 8), (11, 8), (12, 8), (13, 8), (14, 8), (14, 7), (14, 6), (13, 6),
    (12, 6), (11, 6), (10, 6), (9, 6), (8, 5), (8, 4), (8, 3), (8, 2),
    (8, 1), (8, 0), (7, 0), (6, 0),
)
HOME_COLUMN_COORDS = (
    tuple((7, col) for col in range(1, 6)),
    tuple((row, 7) for row in range(1, 6)),
    tuple((7, col) for col in range(13, 8, -1)),
    tuple((row, 7) for row in range(13, 8, -1)),
)
YARD_COORDS = (
    ((2, 2), (2, 4), (4, 2), (4, 4)),
    ((2, 11), (2, 13), (4, 11), (4, 13)),
    ((11, 11), (11, 13), (13, 11), (13, 13)),
    ((11, 2), (11, 4), (13, 2), (13, 4)),
)

def seats_for(num_players):
    if num_players == 2:
        return (0, 2)
    if num_players in (3, 4):
        return tuple(range(num_players))
    raise ValueError('Ludo supports 2, 3 or 4 players')

def on_track(rel):
    return 0 <= rel <= LAST_TRACK

def abs_square(player, rel):
    if on_track(rel):
        return (START_SQUARE[player] + rel) % TRACK_LEN
    return None

def is_safe(player, rel):
    sq = abs_square(player, rel)
    if sq is None:
        return rel != YARD
    return sq in SAFE_SQUARES
