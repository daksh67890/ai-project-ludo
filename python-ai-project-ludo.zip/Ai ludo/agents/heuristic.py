from dataclasses import dataclass
from typing import Optional

from board import HOME, HOME_COLUMN_START, LAST_TRACK, SAFE_SQUARES, START_SQUARE, TRACK_LEN, YARD, on_track
from rules import tokens_on_square


@dataclass(frozen=True)
class HeuristicWeights:
    progress: float = 1.0
    finished: float = 5.0
    capture: float = 2.5
    risk: float = 3.0
    safe: float = 1.3
    opponent_progress: float = 1.4
    yard_penalty: float = 1.8
    invested_risk: float = 3.5
    ambush_value: float = 2.0
    home_stretch: float = 1.2
    blockade: float = 0.8


DEFAULT_WEIGHTS = HeuristicWeights()


def _progress(state, player: int) -> float:
    return sum(max(0, min(position, HOME)) / HOME for position in state.pos[player])


def _capture_opportunities(state, player: int) -> int:
    count = 0
    for relative in state.pos[player]:
        if not on_track(relative):
            continue
        for roll in range(1, 7):
            destination = relative + roll
            if destination > LAST_TRACK:
                continue
            square = (START_SQUARE[player] + destination) % TRACK_LEN
            if square not in SAFE_SQUARES:
                count += len(tokens_on_square(state, square, exclude=player))
    return count


def _at_risk(state, player: int) -> int:
    risk = 0
    for relative in state.pos[player]:
        if not on_track(relative):
            continue
        square = (START_SQUARE[player] + relative) % TRACK_LEN
        if square in SAFE_SQUARES:
            continue
        threatened = False
        for opponent in state.players:
            if opponent == player:
                continue
            for opponent_relative in state.pos[opponent]:
                if not on_track(opponent_relative):
                    continue
                for roll in range(1, 7):
                    destination = opponent_relative + roll
                    if destination <= LAST_TRACK and (START_SQUARE[opponent] + destination) % TRACK_LEN == square:
                        threatened = True
                        break
                if threatened:
                    break
            if threatened:
                break
        risk += int(threatened)
    return risk


def _invested_risk_and_ambush(state, player: int):
    """Calculate proportional risk (risk scaled by lost progress) and ambush value."""
    invested_risk = 0.0
    ambush_val = 0.0

    # Build lookup of opponent tokens on track: square -> list of (opponent, opp_rel)
    opp_tokens_by_square = {}
    for opponent in state.players:
        if opponent == player:
            continue
        for opp_rel in state.pos[opponent]:
            if on_track(opp_rel):
                sq = (START_SQUARE[opponent] + opp_rel) % TRACK_LEN
                opp_tokens_by_square.setdefault(sq, []).append((opponent, opp_rel))

    for rel in state.pos[player]:
        if not on_track(rel):
            continue
        sq = (START_SQUARE[player] + rel) % TRACK_LEN
        is_sq_safe = sq in SAFE_SQUARES

        if not is_sq_safe:
            # Check if any opponent is 1-6 squares behind on track
            threat_count = 0
            for back_dist in range(1, 7):
                attacker_sq = (sq - back_dist) % TRACK_LEN
                if attacker_sq in opp_tokens_by_square:
                    threat_count += len(opp_tokens_by_square[attacker_sq])
            if threat_count > 0:
                # Severity scales with how far the token has traveled
                progress_fraction = max(0.1, rel / HOME)
                invested_risk += progress_fraction * min(threat_count, 3)

        # Ambush: check if this token can reach an opponent in 1-6 squares
        for forward_dist in range(1, 7):
            dest_rel = rel + forward_dist
            if dest_rel <= LAST_TRACK:
                target_sq = (START_SQUARE[player] + dest_rel) % TRACK_LEN
                if target_sq not in SAFE_SQUARES and target_sq in opp_tokens_by_square:
                    for _, opp_rel in opp_tokens_by_square[target_sq]:
                        ambush_val += (opp_rel / HOME) + 0.5

    return invested_risk, ambush_val


def evaluate(state, player: int, weights: HeuristicWeights = DEFAULT_WEIGHTS) -> float:
    if state.winner() == player:
        return 10000.0
    if state.winner() is not None:
        return -10000.0

    own = state.pos[player]
    finished = sum(position == HOME for position in own)
    safe = sum(
        on_track(position)
        and (START_SQUARE[player] + position) % TRACK_LEN in SAFE_SQUARES
        for position in own
    )
    home_stretch_tokens = sum(HOME_COLUMN_START <= pos < HOME for pos in own)
    in_yard = sum(pos == YARD for pos in own)

    # Check for blockades/doubles
    track_counts = {}
    for pos in own:
        if on_track(pos):
            track_counts[pos] = track_counts.get(pos, 0) + 1
    blockades = sum(1 for count in track_counts.values() if count >= 2)

    opponents = [opponent for opponent in state.players if opponent != player]
    opponent_lead = max((_progress(state, opponent) for opponent in opponents), default=0.0)

    # Standard metrics
    score = (
        weights.progress * _progress(state, player)
        + weights.finished * finished
        + weights.capture * _capture_opportunities(state, player)
        - weights.risk * _at_risk(state, player)
        + weights.safe * safe
        - weights.opponent_progress * opponent_lead
    )

    # Advanced positional nuances
    invested_risk, ambush_val = _invested_risk_and_ambush(state, player)
    score += (
        - weights.yard_penalty * in_yard
        - weights.invested_risk * invested_risk
        + weights.ambush_value * ambush_val
        + weights.home_stretch * home_stretch_tokens
        + weights.blockade * blockades
    )

    return score
