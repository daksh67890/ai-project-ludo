from agents.heuristic import DEFAULT_WEIGHTS, HeuristicWeights, evaluate
from rules import apply_move, get_legal_moves

from .common import Agent, Decision


class GreedyAgent(Agent):
    def __init__(self, weights: HeuristicWeights = DEFAULT_WEIGHTS):
        self.weights = weights

    def choose_move(self, state, dice: int) -> Decision:
        moves = get_legal_moves(state, dice)
        if not moves:
            return Decision(None)
        scored = [
            (evaluate(apply_move(state, move), state.turn, self.weights), move)
            for move in moves
        ]
        score, move = max(scored, key=lambda item: item[0])
        return Decision(move, score, len(moves))