import random

from .expectiminimax import ExpectiminimaxAgent
from .greedy_agent import GreedyAgent
from .heuristic import DEFAULT_WEIGHTS, HeuristicWeights
from .random_agent import RandomAgent


def create_agent(name: str, weights: HeuristicWeights = DEFAULT_WEIGHTS, depth: int = 2, seed=None):
    normalized = name.strip().lower()
    if normalized == 'random':
        return RandomAgent(random.Random(seed))
    if normalized == 'greedy':
        return GreedyAgent(weights)
    if normalized in ('expectiminimax', 'search'):
        return ExpectiminimaxAgent(depth, weights)
    if normalized in ('tuned', 'annealed'):
        from optimization.tuner import load_weights

        return GreedyAgent(load_weights() if weights == DEFAULT_WEIGHTS else weights)
    raise ValueError(f'unknown agent: {name}')

