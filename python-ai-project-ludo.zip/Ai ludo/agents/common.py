from dataclasses import dataclass
from typing import Optional

from rules import Move


@dataclass(frozen=True)
class Decision:
    move: Optional[Move]
    score: float = 0.0
    nodes: int = 0


class Agent:
    def choose_move(self, state, dice: int) -> Decision:
        raise NotImplementedError