import random

from rules import get_legal_moves

from .common import Agent, Decision


class RandomAgent(Agent):
    def __init__(self, rng=None):
        self.rng = rng or random.Random()

    def choose_move(self, state, dice: int) -> Decision:
        moves = get_legal_moves(state, dice)
        return Decision(self.rng.choice(moves) if moves else None)