import math
from typing import Dict, Tuple

from rules import apply_move, get_legal_moves, pass_turn

from .common import Agent, Decision
from .heuristic import DEFAULT_WEIGHTS, HeuristicWeights, evaluate

INF = math.inf


class ExpectiminimaxAgent(Agent):
    """Depth-limited Expectiminimax with Star1 alpha-beta pruning.

    Tree: decision nodes (max for the searching player, min for every opponent,
    i.e. the paranoid assumption) alternate with chance nodes that average over
    the six dice outcomes. Depth counts plies (one move = one ply).

    Pruning uses fail-hard alpha-beta. A chance node narrows the window of each
    dice outcome using the known value range, so it can stop early. Heuristic
    values are clamped to (VALUE_FLOOR, VALUE_LIMIT) and a won or lost game is
    exactly VALUE_LIMIT or VALUE_FLOOR. The range is far wider than real
    heuristic values (about -25 to +40), so the bounds stay valid for any
    reasonable weights. The transposition table only stores exact values,
    never cut-off bounds.

    prune=False, use_table=False gives plain Expectiminimax, used as the
    reference in tests and in the search benchmark.
    """

    VALUE_LIMIT = 1000.0
    VALUE_FLOOR = -1000.0

    def __init__(self, depth: int = 2, weights: HeuristicWeights = DEFAULT_WEIGHTS,
                 prune: bool = True, use_table: bool = True, order_moves: bool = True):
        if depth < 1:
            raise ValueError('depth must be at least 1')
        self.depth = depth
        self.weights = weights
        self.prune = prune
        self.use_table = use_table
        self.order_moves = order_moves
        self.nodes = 0
        self.root_player = 0
        self._tt: Dict[Tuple, float] = {}

    def choose_move(self, state, dice: int) -> Decision:
        moves = get_legal_moves(state, dice)
        if not moves:
            return Decision(None, evaluate(state, state.turn, self.weights), 1)

        self.nodes = 0
        self.root_player = state.turn
        self._tt.clear()
        best_score = -INF
        best_move = moves[0]
        alpha = -INF
        for move in self._ordered_moves(state, moves, maximizing=True):
            score = self._expecti(apply_move(state, move), self.depth - 1, alpha, INF)
            if score > best_score:
                best_score, best_move = score, move
            if self.prune:
                alpha = max(alpha, best_score)
        return Decision(best_move, best_score, self.nodes)

    def _expecti(self, state, remaining: int, alpha: float, beta: float) -> float:
        self.nodes += 1
        winner = state.winner()
        if winner is not None:
            return self.VALUE_LIMIT if winner == self.root_player else self.VALUE_FLOOR
        if remaining <= 0:
            value = evaluate(state, self.root_player, self.weights)
            return min(max(value, self.VALUE_FLOOR + 1.0), self.VALUE_LIMIT - 1.0)

        key = None
        if self.use_table:
            key = (state.pos, state.turn, state.sixes, remaining)
            cached = self._tt.get(key)
            if cached is not None:
                return cached

        total = 0.0
        if not self.prune:
            for dice in range(1, 7):
                total += self._decision_for_roll(state, dice, remaining, -INF, INF)
        else:
            for index in range(6):
                outcomes_left = 5 - index
                low = 6.0 * alpha - total - outcomes_left * self.VALUE_LIMIT
                high = 6.0 * beta - total - outcomes_left * self.VALUE_FLOOR
                value = self._decision_for_roll(
                    state, index + 1, remaining,
                    max(low, self.VALUE_FLOOR), min(high, self.VALUE_LIMIT),
                )
                if value <= low:
                    return alpha
                if value >= high:
                    return beta
                total += value

        result = total / 6.0
        if key is not None:
            self._tt[key] = result
        return result

    def _decision_for_roll(self, state, dice: int, remaining: int, alpha: float, beta: float) -> float:
        self.nodes += 1
        moves = get_legal_moves(state, dice)
        if not moves:
            return self._expecti(pass_turn(state), remaining - 1, alpha, beta)

        maximizing = state.turn == self.root_player
        best = -INF if maximizing else INF
        for move in self._ordered_moves(state, moves, maximizing):
            value = self._expecti(apply_move(state, move), remaining - 1, alpha, beta)
            if maximizing:
                best = max(best, value)
                alpha = max(alpha, best)
            else:
                best = min(best, value)
                beta = min(beta, best)
            if self.prune and alpha >= beta:
                break
        return best

    def _ordered_moves(self, state, moves, maximizing: bool):
        if not self.order_moves or len(moves) < 2:
            return moves
        scored = [
            (evaluate(apply_move(state, move), self.root_player, self.weights), move)
            for move in moves
        ]
        scored.sort(key=lambda item: item[0], reverse=maximizing)
        return [move for _, move in scored]
