__all__ = ['load_weights', 'save_weights', 'tune_weights']


def __getattr__(name):
	if name in __all__:
		from . import tuner

		return getattr(tuner, name)
	raise AttributeError(f'module {__name__!r} has no attribute {name!r}')