import json
import math
import random
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Optional

from agents.common import Agent
from agents.greedy_agent import GreedyAgent
from agents.heuristic import DEFAULT_WEIGHTS, HeuristicWeights
from agents.random_agent import RandomAgent
from rules import apply_move, get_legal_moves, pass_turn, roll_dice
from state import new_game

FINAL_SEED_OFFSET = 5_000_000
VALIDATION_SEED_OFFSET = 90_000_000


def _play(weights: HeuristicWeights, seed: int, opponent_type: str = 'greedy',
          baseline: HeuristicWeights = DEFAULT_WEIGHTS, max_turns: int = 3000) -> int:
    rng = random.Random(seed)
    state = new_game(2)
    tuned_player = (seed % 2) * 2
    opp_player = 2 - tuned_player

    if opponent_type == 'random':
        opp_agent = RandomAgent(random.Random(seed + 1_000_003))
    elif opponent_type == 'mixed' and seed % 4 == 0:
        opp_agent = RandomAgent(random.Random(seed + 1_000_003))
    else:
        opp_agent = GreedyAgent(baseline)

    agents: Dict[int, Agent] = {
        tuned_player: GreedyAgent(weights),
        opp_player: opp_agent,
    }
    for _ in range(max_turns):
        if state.is_terminal():
            break
        dice = roll_dice(rng)
        moves = get_legal_moves(state, dice)
        if not moves:
            state = pass_turn(state)
            continue
        decision = agents[state.turn].choose_move(state, dice)
        state = apply_move(state, decision.move)
    return int(state.winner() == tuned_player)


def _fitness(weights: HeuristicWeights, games: int, seed: int, opponent_type: str = 'greedy',
             baseline: HeuristicWeights = DEFAULT_WEIGHTS) -> float:
    half = max(1, games // 2)
    s1 = sum(_play(weights, seed + index * 2, opponent_type, baseline) for index in range(half))
    s2 = sum(_play(weights, seed + index * 2 + 1, opponent_type, baseline) for index in range(half))
    return (s1 + s2) / (half * 2)


def compare_weights(weights: HeuristicWeights, baseline: HeuristicWeights = DEFAULT_WEIGHTS,
                    games: int = 1000, seed: int = 0) -> float:
    """Win rate of a Greedy agent using `weights` against a Greedy agent using `baseline`.

    Uses seeds that the tuner never uses, and plays both seats equally often.
    """
    return _fitness(weights, games, VALIDATION_SEED_OFFSET + seed * 10_000_000, 'greedy', baseline)


def tune_weights(
    initial: HeuristicWeights = DEFAULT_WEIGHTS,
    iterations: int = 30,
    games_per_candidate: int = 8,
    seed: int = 0,
    opponent: str = 'greedy',
    temperature: float = 0.05,
    cooling: float = 0.97,
    finalists: int = 3,
    final_games: Optional[int] = None,
) -> HeuristicWeights:
    """Simulated annealing over the heuristic weights.

    Each candidate is scored by its win rate against the default weights. Scores
    from a few games are noisy, so the best `finalists` candidates (plus the
    initial weights) are replayed on fresh seeds with more games before the
    winner is chosen. This avoids picking a candidate that was only lucky.
    """
    if iterations < 1 or games_per_candidate < 1:
        raise ValueError('iterations and games_per_candidate must be positive')
    if final_games is None:
        final_games = games_per_candidate * 5
    rng = random.Random(seed)
    current = initial
    current_score = _fitness(current, games_per_candidate, seed, opponent)
    scored = {current: current_score}
    names = tuple(asdict(initial))
    temp = temperature

    for iteration in range(iterations):
        values = asdict(current)
        name = rng.choice(names)
        step = rng.uniform(-1.2, 1.2)
        values[name] = max(0.05, round(values[name] + step, 3))
        candidate = HeuristicWeights(**values)
        score = _fitness(candidate, games_per_candidate, seed + (iteration + 1) * games_per_candidate, opponent)
        scored[candidate] = score
        if score >= current_score or rng.random() < math.exp((score - current_score) / max(temp, 1e-6)):
            current, current_score = candidate, score
        temp *= cooling

    ranked = sorted(scored, key=lambda w: scored[w], reverse=True)
    pool = [initial] + [w for w in ranked if w != initial][:max(0, finalists)]
    final_seed = seed + FINAL_SEED_OFFSET
    return max(pool, key=lambda w: _fitness(w, final_games, final_seed, opponent))


def uniform_weights() -> HeuristicWeights:
    return HeuristicWeights(**{name: 1.0 for name in asdict(DEFAULT_WEIGHTS)})


def save_weights(weights: HeuristicWeights, path: Path = Path(__file__).with_name('tuned_weights.json')) -> None:
    path.write_text(json.dumps(asdict(weights), indent=2), encoding='utf-8')


def load_weights(path: Path = Path(__file__).with_name('tuned_weights.json')) -> HeuristicWeights:
    if not path.exists():
        return DEFAULT_WEIGHTS
    return HeuristicWeights(**json.loads(path.read_text(encoding='utf-8')))


def main():
    import argparse

    parser = argparse.ArgumentParser(description='Tune greedy heuristic weights with simulated annealing.')
    parser.add_argument('--iterations', type=int, default=60)
    parser.add_argument('--games', type=int, default=40, help='Games per candidate')
    parser.add_argument('--final-games', type=int, default=None, help='Games per finalist (default 5 x --games)')
    parser.add_argument('--validate', type=int, default=1000, help='Held-out games against the default weights (0 to skip)')
    parser.add_argument('--start', choices=('default', 'uniform'), default='default',
                        help='Initial weights: the hand-built defaults, or every weight set to 1.0')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--opponent', type=str, choices=('greedy', 'random', 'mixed'), default='greedy')
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('tuned_weights.json'))
    args = parser.parse_args()
    initial = DEFAULT_WEIGHTS if args.start == 'default' else uniform_weights()
    if args.validate:
        start_rate = compare_weights(initial, DEFAULT_WEIGHTS, args.validate, args.seed)
        print(f'Starting weights: held-out win rate vs default weights {start_rate:.1%}')
    weights = tune_weights(initial=initial, iterations=args.iterations, games_per_candidate=args.games, seed=args.seed,
                           opponent=args.opponent, final_games=args.final_games)
    save_weights(weights, args.output)
    print(f'Saved weights to {args.output}: {weights}')
    if args.validate:
        rate = compare_weights(weights, DEFAULT_WEIGHTS, args.validate, args.seed)
        margin = 1.96 * math.sqrt(rate * (1 - rate) / args.validate)
        print(f'Held-out win rate vs default weights over {args.validate} games: {rate:.1%} +/- {margin:.1%}')


if __name__ == '__main__':
    main()
