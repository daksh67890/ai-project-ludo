import argparse
import csv
import random
import time
from pathlib import Path

from agents.expectiminimax import ExpectiminimaxAgent
from rules import apply_move, get_legal_moves, pass_turn, roll_dice
from state import new_game

VARIANTS = {
    'plain': {'prune': False, 'use_table': False},
    'alpha-beta': {'prune': True, 'use_table': False},
    'alpha-beta + table': {'prune': True, 'use_table': True},
}


def sample_positions(num_players, count, seed):
    """Positions from random games where the player to move has at least two legal moves."""
    rng = random.Random(seed)
    positions = []
    state = new_game(num_players)
    while len(positions) < count:
        if state.is_terminal():
            state = new_game(num_players)
        dice = roll_dice(rng)
        moves = get_legal_moves(state, dice)
        if len(moves) >= 2 and rng.random() < 0.3:
            positions.append((state, dice))
        state = apply_move(state, rng.choice(moves)) if moves else pass_turn(state)
    return positions


def run_benchmark(players=(2, 4), depths=(1, 2, 3), positions=60, deep_positions=25, deep_from=3, seed=2026):
    rows = []
    for num_players in players:
        pool = sample_positions(num_players, max(positions, deep_positions), seed + num_players)
        for depth in depths:
            sample = pool[: deep_positions if depth >= deep_from else positions]
            reference = None
            for variant, options in VARIANTS.items():
                agent = ExpectiminimaxAgent(depth, **options)
                scores, nodes, seconds = [], 0, 0.0
                for state, dice in sample:
                    start = time.perf_counter()
                    decision = agent.choose_move(state, dice)
                    seconds += time.perf_counter() - start
                    nodes += decision.nodes
                    scores.append(decision.score)
                if reference is None:
                    reference = scores
                same = sum(abs(a - b) < 1e-6 for a, b in zip(scores, reference))
                rows.append({
                    'players': num_players,
                    'depth': depth,
                    'variant': variant,
                    'positions': len(sample),
                    'avg_nodes': nodes / len(sample),
                    'avg_ms': 1000 * seconds / len(sample),
                    'same_score_as_plain': f'{same}/{len(sample)}',
                })
    return rows


def write_csv(rows, path):
    with path.open('w', newline='', encoding='utf-8') as output:
        writer = csv.DictWriter(output, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def plot_rows(rows, path):
    import matplotlib.pyplot as plt

    players = sorted({row['players'] for row in rows})
    figure, axes = plt.subplots(1, len(players), figsize=(6 * len(players), 4), squeeze=False)
    colors = {'plain': '#d85b48', 'alpha-beta': '#d2a83c', 'alpha-beta + table': '#5a9a72'}
    for axis, num_players in zip(axes[0], players):
        subset = [row for row in rows if row['players'] == num_players]
        depths = sorted({row['depth'] for row in subset})
        width = 0.26
        for offset, variant in enumerate(VARIANTS):
            values = [next(r['avg_nodes'] for r in subset if r['depth'] == d and r['variant'] == variant) for d in depths]
            axis.bar([i + (offset - 1) * width for i in range(len(depths))], values, width, label=variant, color=colors[variant])
        axis.set_xticks(range(len(depths)))
        axis.set_xticklabels([f'depth {d}' for d in depths])
        axis.set_yscale('log')
        axis.set(title=f'{num_players} players: nodes per move', ylabel='Nodes (log scale)')
        axis.legend()
    figure.tight_layout()
    figure.savefig(path, dpi=160)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description='Compare plain Expectiminimax, alpha-beta, and alpha-beta with a transposition table.')
    parser.add_argument('--positions', type=int, default=60)
    parser.add_argument('--deep-positions', type=int, default=25, help='Positions used for depth 3 and above')
    parser.add_argument('--depths', type=int, nargs='+', default=[1, 2, 3])
    parser.add_argument('--seed', type=int, default=2026)
    parser.add_argument('--csv', type=Path, default=Path('experiments/search_benchmark.csv'))
    parser.add_argument('--plot', type=Path, default=Path('experiments/search_benchmark.png'))
    args = parser.parse_args()
    rows = run_benchmark(depths=tuple(args.depths), positions=args.positions,
                         deep_positions=args.deep_positions, seed=args.seed)
    print(f"{'players':>7} {'depth':>5} {'variant':<20} {'positions':>9} {'nodes/move':>11} {'ms/move':>9} {'same score':>11}")
    for row in rows:
        print(f"{row['players']:>7} {row['depth']:>5} {row['variant']:<20} {row['positions']:>9} "
              f"{row['avg_nodes']:>11.1f} {row['avg_ms']:>9.2f} {row['same_score_as_plain']:>11}")
    write_csv(rows, args.csv)
    try:
        plot_rows(rows, args.plot)
    except ImportError:
        print('matplotlib not installed; skipped chart')


if __name__ == '__main__':
    main()
