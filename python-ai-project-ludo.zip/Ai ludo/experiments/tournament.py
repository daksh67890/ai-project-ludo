import argparse
import csv
import json
import random
import time
from collections import Counter, defaultdict
from pathlib import Path

from agents.factory import create_agent
from rules import apply_move, get_legal_moves, pass_turn, roll_dice
from state import new_game


def build_schedule(agent_names, games, num_players):
    """Return one tuple of agent names (one per seat) for every game to play.

    2 players, 3+ agents: round robin. Every ordered pair (a, b) plays the same
    number of games, so each agent meets every other agent equally often and
    plays both seats equally often. The number of games is rounded down to a
    multiple of the number of ordered pairs.

    2 players, 2 agents: seats alternate every game.
    3 or 4 players: names rotate across the seats, so each agent plays every seat.
    """
    names = list(agent_names)
    if num_players == 2:
        if len(names) == 1:
            return [(names[0], names[0])] * games
        if len(names) == 2:
            return [(names[0], names[1]) if g % 2 == 0 else (names[1], names[0]) for g in range(games)]
        ordered_pairs = [(a, b) for a in names for b in names if a != b]
        per_pair = max(1, games // len(ordered_pairs))
        return [pair for _ in range(per_pair) for pair in ordered_pairs]
    return [
        tuple(names[(seat_index + g) % len(names)] for seat_index in range(num_players))
        for g in range(games)
    ]


def run_tournament(agent_names, games=100, num_players=2, depth=2, seed=0, max_turns=5000):
    if games < 1:
        raise ValueError('games must be positive')
    if not agent_names:
        raise ValueError('provide at least one agent')
    if max_turns < 1:
        raise ValueError('max_turns must be positive')
    rng = random.Random(seed)
    agent_rng = random.Random(seed * 7919 + 13)
    wins = Counter()
    totals = defaultdict(float)
    agent_totals = defaultdict(lambda: defaultdict(float))
    pairwise = defaultdict(lambda: [0, 0])
    schedule = build_schedule(agent_names, games, num_players)
    games = len(schedule)
    start = time.perf_counter()

    for game_names in schedule:
        state = new_game(num_players)
        seat_names = dict(zip(state.players, game_names))
        seat_agents = {
            player: create_agent(name, depth=depth, seed=agent_rng.getrandbits(32))
            for player, name in seat_names.items()
        }
        for name in seat_names.values():
            agent_totals[name]['games'] += 1
        turn_number = 0
        for turn_number in range(1, max_turns + 1):
            if state.is_terminal():
                break
            dice = roll_dice(rng)
            moves = get_legal_moves(state, dice)
            if not moves:
                state = pass_turn(state)
                continue
            agent = seat_agents[state.turn]
            move_start = time.perf_counter()
            decision = agent.choose_move(state, dice)
            move_seconds = time.perf_counter() - move_start
            totals['nodes'] += decision.nodes
            totals['decisions'] += 1
            totals['captures'] += len(decision.move.captured)
            name = seat_names[state.turn]
            agent_totals[name]['nodes'] += decision.nodes
            agent_totals[name]['decisions'] += 1
            agent_totals[name]['move_seconds'] += move_seconds
            agent_totals[name]['captures'] += len(decision.move.captured)
            state = apply_move(state, decision.move)
        winner = state.winner()
        wins[winner] += 1
        if winner is not None:
            agent_totals[seat_names[winner]]['wins'] += 1
        if num_players == 2 and len(set(game_names)) == 2:
            first, second = sorted(game_names)
            pairwise[f'{first} vs {second}'][0] += 1
            if winner is not None and seat_names[winner] == first:
                pairwise[f'{first} vs {second}'][1] += 1
        totals['turns'] += turn_number
        totals['completed'] += int(winner is not None)

    elapsed = time.perf_counter() - start
    agent_metrics = {}
    for name, metrics in agent_totals.items():
        decisions = max(1, metrics['decisions'])
        agent_games = max(1, metrics['games'])
        agent_metrics[name] = {
            'games': int(metrics['games']),
            'wins': int(metrics['wins']),
            'win_rate': metrics['wins'] / agent_games,
            'average_nodes_per_move': metrics['nodes'] / decisions,
            'average_seconds_per_move': metrics['move_seconds'] / decisions,
            'captures_per_game': metrics['captures'] / agent_games,
        }
    pairwise_metrics = {
        pair: {'games': games_played, 'first_wins': first_wins, 'first_win_rate': first_wins / games_played}
        for pair, (games_played, first_wins) in sorted(pairwise.items())
    }

    return {
        'games': games,
        'players': num_players,
        'depth': depth,
        'seed': seed,
        'wins': dict(wins),
        'agent_metrics': json.dumps(agent_metrics, sort_keys=True),
        'pairwise': json.dumps(pairwise_metrics, sort_keys=True),
        'win_rate_by_seat': {str(seat): wins[seat] / games for seat in range(4)},
        'completion_rate': totals['completed'] / games,
        'average_turns': totals['turns'] / games,
        'average_nodes_per_decision': totals['nodes'] / max(1, totals['decisions']),
        'average_seconds_per_move': elapsed / max(1, totals['decisions']),
        'captures_per_game': totals['captures'] / games,
        'seconds': elapsed,
        'games_per_second': games / max(elapsed, 1e-9),
    }


def main():
    parser = argparse.ArgumentParser(description='Run a headless AI Ludo tournament.')
    parser.add_argument('--agents', nargs='+', default=['random', 'greedy'])
    parser.add_argument('--games', type=int, default=100,
                        help='Total games. For 2 players with 3+ agents this is rounded down to a multiple of the ordered pairs.')
    parser.add_argument('--players', type=int, choices=(2, 3, 4), default=2)
    parser.add_argument('--depth', type=int, default=2)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--csv', type=Path)
    args = parser.parse_args()
    result = run_tournament(args.agents, args.games, args.players, args.depth, args.seed)
    for key, value in result.items():
        print(f'{key}: {value}')
    if args.csv:
        with args.csv.open('w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=result.keys())
            writer.writeheader()
            writer.writerow(result)


if __name__ == '__main__':
    main()
