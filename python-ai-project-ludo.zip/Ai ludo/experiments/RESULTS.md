# AI Ludo Experiment Results

All numbers can be regenerated with the commands in `README.md`. All games finished (completion rate 100%). Margins are 95% intervals.

## Method

- Rules: defaults (6 to leave the yard, exact finish, extra turn on 6 / capture / home, three sixes forfeit, no blocks).
- Expectiminimax depth: 2. Seed: 2026 for dice and for the Random agent.
- **2 players:** balanced round robin over 4 agents. There are 12 ordered pairs and each plays 100 games, so every agent plays 600 games, meets each opponent in 200 games, and plays each seat equally often.
- **4 players:** all four agents sit at the table in every game and rotate through the seats, 1000 games.

## Two players (1200 games, average game 160 turns)

| Agent | Games | Wins | Win rate | Captures / game | Nodes / move | ms / move |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Expectiminimax | 600 | 374 | 62.3% +/- 3.9 | 0.97 | 40.8 | 1.33 |
| Tuned | 600 | 323 | 53.8% +/- 4.0 | 0.39 | 2.1 | 0.06 |
| Greedy | 600 | 317 | 52.8% +/- 4.0 | 0.44 | 2.1 | 0.05 |
| Random | 600 | 186 | 31.0% +/- 3.7 | 0.39 | 0.0 | 0.00 |

Head-to-head (first agent's win rate, 200 games each):

| Matchup | Win rate |
| :--- | :---: |
| Expectiminimax vs Random | 77.0% +/- 5.8 |
| Expectiminimax vs Greedy | 57.0% +/- 6.9 |
| Expectiminimax vs Tuned | 53.0% +/- 6.9 |
| Greedy vs Random | 63.5% +/- 6.7 |
| Tuned vs Random | 66.5% +/- 6.5 (Random vs Tuned: 33.5%) |
| Greedy vs Tuned | 52.0% +/- 6.9 |

## Four players (1000 games, average game 322 turns, fair share 25%)

| Agent | Wins | Win rate | Captures / game | Nodes / move | ms / move |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Expectiminimax | 335 | 33.5% +/- 2.9 | 2.28 | 44.5 | 2.48 |
| Greedy | 277 | 27.7% +/- 2.8 | 1.61 | 2.2 | 0.09 |
| Tuned | 259 | 25.9% +/- 2.7 | 1.53 | 2.2 | 0.10 |
| Random | 129 | 12.9% +/- 2.1 | 1.49 | 0.0 | 0.01 |

## Search cost: plain vs alpha-beta vs alpha-beta + table

Positions are sampled from random games where the player has at least two legal moves (60 positions at depths 1 and 2, 25 at depth 3). Every variant returned the same score as plain Expectiminimax in every position.

| Players | Depth | Plain nodes | Alpha-beta nodes | + Table nodes | Plain ms | Alpha-beta ms | + Table ms |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| 2 | 1 | 2.5 | 2.5 | 2.5 | 0.12 | 0.12 | 0.12 |
| 2 | 2 | 45.6 | 44.5 | 44.5 | 1.38 | 1.47 | 1.19 |
| 2 | 3 | 666.9 | 623.1 | 606.3 | 19.2 | 18.3 | 19.9 |
| 4 | 1 | 2.6 | 2.6 | 2.6 | 0.19 | 0.19 | 0.19 |
| 4 | 2 | 44.6 | 43.8 | 43.8 | 1.80 | 1.77 | 1.77 |
| 4 | 3 | 495.5 | 477.4 | 426.7 | 20.4 | 19.8 | 17.0 |

Each extra ply multiplies the cost by about 11 to 15. Pruning removes only 2 to 7% of the nodes and the table another 0 to 11%. The reason is the shape of the tree: many dice values leave only one or two legal moves (and tokens on the same square count once), so there is little to cut. Tightening the value bounds used by the chance-node pruning from +/-10000 to +/-1000 left the node counts unchanged, and +/-100 changed them by only a few percent.

## Search correctness

The pruned search with the table was compared against plain Expectiminimax, which has no pruning and no table:

- 1524 sampled positions (2 and 4 players, depths 2 to 4, with and without the table and move ordering) checked against an independent reference search: no differences in score or in the value of the chosen move.
- `tests/test_fixes.py` repeats this check for every option combination.
- An earlier version that stored cut-off bounds as exact values and compared rounded totals chose a worse move in a few sampled depth-3 positions (1 to 2 out of 64 in one paired run). It was replaced.

## Weight tuning (simulated annealing)

The tuner scores each candidate by a Greedy agent's win rate against Greedy with the default weights, replays the best candidates on fresh games, and checks the winner on held-out games.

| Run | Result |
| :--- | :--- |
| Start from default weights, 150 iterations x 100 games, finalists 600 games each, seed 7 | No candidate beat the defaults in the final replay, so the defaults were returned. Held-out check of the result against the defaults: 50.6% +/- 2.2 (2000 games, a sanity check, since it is the same agent). |
| Start from all weights = 1.0, 150 iterations x 100 games, seed 11 | The starting weights already win 49.0% +/- 3.1 against the defaults (1000 games), and no candidate beat them in the final replay. |
| Weights saved by the earlier tuner run | 48.6% +/- 2.2 against the defaults (2000 games): no gain. |

The Greedy agent's win rate is almost flat across the weight settings we tried, so annealing has little to find. The hand-built defaults are about as good as anything the tuner reached, and the saved `tuned_weights.json` therefore contains the defaults. The "Tuned" agent is kept so that the comparison is visible: its results match Greedy within the margin of error.

## Conclusions

- Depth-2 Expectiminimax is the strongest agent in both settings: 62.3% in 2 players (against 52.8% for Greedy) and 33.5% in 4 players (against 25% for a fair share). Its advantage over Greedy in a direct match (57.0% +/- 6.9) is borderline.
- Search is clearly better than 1-ply play against a weak opponent (77.0% against Random, 63.5% for Greedy).
- Every agent beats Random, so the heuristic captures real Ludo strategy.
- Pruning is correct but saves little in this game, and the depth is limited by the cost growth (about 11 to 15 times per ply).
- Tuning the weights did not improve on the defaults in our tests.
