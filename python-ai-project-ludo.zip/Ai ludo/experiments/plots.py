import argparse
import csv
import json
from pathlib import Path


def plot_results(csv_path: Path, output: Path):
    try:
        import matplotlib.pyplot as plt
    except ImportError as error:
        raise RuntimeError('Install chart dependencies with: python -m pip install -r requirements.txt') from error

    with csv_path.open(newline='', encoding='utf-8') as source:
        rows = list(csv.DictReader(source))
    if not rows:
        raise ValueError('CSV contains no tournament results')
    row = rows[-1]
    agent_metrics = json.loads(row['agent_metrics'])
    labels = list(agent_metrics)
    win_rates = [agent_metrics[name]['win_rate'] for name in labels]
    nodes = [agent_metrics[name]['average_nodes_per_move'] for name in labels]
    captures = [agent_metrics[name]['captures_per_game'] for name in labels]

    colors = ['#d85b48', '#5a9a72', '#d2a83c', '#5681b5']
    figure, axes = plt.subplots(1, 3, figsize=(12, 4))
    axes[0].bar(labels, win_rates, color=colors[:len(labels)])
    axes[0].set(title='Win rate by agent', ylabel='Rate', ylim=(0, 1))
    axes[1].bar(labels, nodes, color=colors[:len(labels)])
    axes[1].set(title='Search nodes per move', ylabel='Nodes')
    axes[2].bar(labels, captures, color=colors[:len(labels)])
    axes[2].set(title='Captures per game', ylabel='Captures')
    for axis in axes:
        axis.tick_params(axis='x', labelrotation=25)
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description='Plot metrics from experiments.tournament CSV output.')
    parser.add_argument('csv', type=Path)
    parser.add_argument('--output', type=Path, default=Path('tournament.png'))
    args = parser.parse_args()
    plot_results(args.csv, args.output)
    print(f'Wrote {args.output}')


if __name__ == '__main__':
    main()